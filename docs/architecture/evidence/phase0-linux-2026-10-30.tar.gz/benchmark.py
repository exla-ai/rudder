#!/usr/bin/env python3
import ctypes, datetime, errno, fcntl, hashlib, json, os, pathlib, platform, resource, shutil, statistics, subprocess, sys, tempfile, time

FICLONE = 0x40049409
CASES = [("100-files", 100, 4096, 0), ("10000-files", 10000, 41, 0), ("100-files-plus-8MiB", 100, 4096, 8 * 1024 * 1024)]
NODE_BUILD = r'''import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const cfg = JSON.parse(fs.readFileSync('fixture.json', 'utf8'));
const input = i => path.join('inputs', `g${String(Math.floor(i / 250)).padStart(3,'0')}`, `f${String(i).padStart(5,'0')}.dat`);
if (process.argv.includes('--read')) {
  const first = fs.readFileSync(input(0));
  const prepared = JSON.parse(fs.readFileSync('out/bundle.json','utf8'));
  console.log(JSON.stringify({firstByte:first[0], preparedDigest:prepared.digest}));
} else {
  const hash = crypto.createHash('sha256'); let bytes = 0;
  for (let i=0;i<cfg.files;i++) { const data=fs.readFileSync(input(i)); hash.update(data); bytes+=data.length; }
  if (cfg.blobBytes) { const data=fs.readFileSync('large.bin'); hash.update(data); bytes+=data.length; }
  const result = {digest:hash.digest('hex'), inputBytes:bytes, files:cfg.files + Number(Boolean(cfg.blobBytes))};
  fs.mkdirSync('out',{recursive:true});
  fs.writeFileSync('out/bundle.tmp',JSON.stringify(result)+'\n');
  fs.renameSync('out/bundle.tmp','out/bundle.json');
  console.log(JSON.stringify(result));
}
'''

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def command(args, **kwargs):
    result = subprocess.run(args, text=True, capture_output=True, timeout=kwargs.pop('timeout', 15), **kwargs)
    if result.returncode: raise RuntimeError(json.dumps({'args':args,'code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}))
    return result.stdout.strip()
def cleanup(root):
    if not root.exists(): return
    for current, dirs, files in os.walk(root, topdown=True):
        os.chmod(current, 0o700)
        for name in dirs: os.chmod(pathlib.Path(current)/name, 0o700)
    shutil.rmtree(root)
def stats(root):
    result = {'regularFiles':0,'directories':1,'logicalBytes':0,'allocatedBytes':root.stat().st_blocks*512}
    for current, dirs, files in os.walk(root):
        for name in dirs:
            entry=(pathlib.Path(current)/name).lstat();result['directories']+=1;result['allocatedBytes']+=entry.st_blocks*512
        for name in files:
            entry=(pathlib.Path(current)/name).lstat();result['regularFiles']+=1;result['logicalBytes']+=entry.st_size;result['allocatedBytes']+=entry.st_blocks*512
    return result
def timed_node(root, read=False):
    start=time.perf_counter_ns()
    result=command(['node','build.mjs']+(['--read'] if read else []),cwd=root)
    return (time.perf_counter_ns()-start)/1e6, json.loads(result)
def input_path(root, i=0): return root/'inputs'/f'g{i//250:03d}'/f'f{i:05d}.dat'

def child(data_root, parent_mnt, parent_user):
    os.nice(10)
    namespaces={name:os.readlink('/proc/self/ns/'+name) for name in ['mnt','user']}
    assert namespaces['mnt']!=parent_mnt and namespaces['user']!=parent_user
    assert command(['findmnt','-n','-o','PROPAGATION','/'])=='private'
    libc=ctypes.CDLL(None,use_errno=True)
    libc.mount.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_char_p,ctypes.c_ulong,ctypes.c_void_p]
    libc.umount2.argtypes=[ctypes.c_char_p,ctypes.c_int]
    mounted=[]
    def mount(lower,upper,work,view):
        options=f'userxattr,lowerdir={lower},upperdir={upper},workdir={work}'.encode()
        if libc.mount(b'overlay',str(view).encode(),b'overlay',6,options):
            value=ctypes.get_errno(); raise OSError(value,os.strerror(value))
        mounted.append(view)
    def unmount(view):
        if libc.umount2(str(view).encode(),0):
            value=ctypes.get_errno();raise OSError(value,os.strerror(value))
        mounted.remove(view)
    report={'startedAt':utc(),'namespace':namespaces,'rootPropagation':'private','mountFlags':['MS_NOSUID','MS_NODEV'],'repeatsPerCaseAndViewCount':5,'cases':[]}
    try:
        for name,count,size,blob_bytes in CASES:
            case_root=data_root/name; lower=case_root/'lower';lower.mkdir(parents=True)
            digest=hashlib.sha256()
            create_start=time.perf_counter_ns()
            for i in range(count):
                target=input_path(lower,i);target.parent.mkdir(parents=True,exist_ok=True)
                seed=hashlib.sha256(str(i).encode()).hexdigest().encode()
                payload=(seed*((size+63)//64))[:size]
                target.write_bytes(payload);digest.update(payload)
            if blob_bytes:
                block=bytes(range(256))*4096
                with (lower/'large.bin').open('wb') as stream:
                    for _ in range(blob_bytes//len(block)): stream.write(block);digest.update(block)
            (lower/'fixture.json').write_text(json.dumps({'files':count,'fileBytes':size,'blobBytes':blob_bytes},sort_keys=True)+'\n')
            (lower/'build.mjs').write_text(NODE_BUILD)
            fixture_create_ms=(time.perf_counter_ns()-create_start)/1e6
            prepare_ms,baseline=timed_node(lower)
            assert baseline['digest']==digest.hexdigest()
            lower_stats=stats(lower)
            assert lower_stats['allocatedBytes'] < 48*1024*1024
            case={'name':name,'inputFiles':count,'bytesPerInput':size,'blobBytes':blob_bytes,'inputBytes':count*size+blob_bytes,'lower':lower_stats,'baselineDigest':baseline['digest'],'fixtureCreateMs':fixture_create_ms,'prepareBuildMs':prepare_ms,'samples':[]}
            baseline_output=(lower/'out/bundle.json').read_bytes()
            original_input=input_path(lower).read_bytes()
            for views in [1,10]:
                for trial in range(5):
                    batch=case_root/f'batch-{views}-{trial}'; batch.mkdir()
                    handles=[]
                    start=time.perf_counter_ns()
                    for index in range(views):
                        view_root=batch/str(index);view_root.mkdir()
                        upper=view_root/'upper';work=view_root/'work';view=view_root/'view'
                        for directory in [upper,work,view]:directory.mkdir()
                        mount(lower,upper,work,view);handles.append((upper,work,view))
                    creation_ms=(time.perf_counter_ns()-start)/1e6
                    before=[stats(upper) for upper,_,_ in handles]
                    assert all(entry['regularFiles']==0 and entry['logicalBytes']==0 for entry in before)
                    read_ms,read_value=timed_node(handles[0][2],True)
                    assert read_value['firstByte']==original_input[0] and read_value['preparedDigest']==baseline['digest']
                    build_ms,result=timed_node(handles[0][2])
                    assert result==baseline
                    after_build=stats(handles[0][0])
                    # Different private content in every view, with one identical
                    # pathname. These must never alter the lower or a sibling.
                    for index,(_,_,view) in enumerate(handles):
                        with input_path(view).open('r+b') as stream:stream.write(bytes([65+index]))
                        (view/'private-note.txt').write_text(f'view-{index}\n')
                    for index,(_,_,view) in enumerate(handles):
                        assert input_path(view).read_bytes()[0]==65+index
                        assert (view/'private-note.txt').read_text()==f'view-{index}\n'
                    assert input_path(lower).read_bytes()==original_input
                    assert (lower/'out/bundle.json').read_bytes()==baseline_output
                    assert not (lower/'private-note.txt').exists()
                    edited_build_ms,edited=timed_node(handles[0][2])
                    assert edited['digest']!=baseline['digest']
                    if views>1:assert (handles[1][2]/'out/bundle.json').read_bytes()==baseline_output
                    after_edits=[stats(upper) for upper,_,_ in handles]
                    remount_ms=None
                    if trial==0:
                        upper,work,view=handles[0];unmount(view)
                        start=time.perf_counter_ns();mount(lower,upper,work,view);remount_ms=(time.perf_counter_ns()-start)/1e6
                        assert input_path(view).read_bytes()[0]==65
                        assert (view/'private-note.txt').read_text()=='view-0\n'
                        assert json.loads((view/'out/bundle.json').read_text())==edited
                    # Count only source and real upper/work allocations, never
                    # sum merged views, which would count inherited blocks again.
                    upper_work_bytes=sum(stats(upper)['allocatedBytes']+stats(work)['allocatedBytes'] for upper,work,_ in handles)
                    assert lower_stats['allocatedBytes']+upper_work_bytes <64*1024*1024
                    case['samples'].append({'views':views,'trial':trial+1,'createMs':creation_ms,'firstReadMs':read_ms,'firstBuildMs':build_ms,'editedBuildMs':edited_build_ms,'upperBefore':[entry['regularFiles'] for entry in before],'upperAfterBuild':after_build,'upperAfterEdits':after_edits,'upperWorkAllocatedBytes':upper_work_bytes,'remountMs':remount_ms,'parentIsolation':True,'perViewIsolation':True,'siblingInheritedBuildUnchanged':True if views>1 else None})
                    for _,_,view in reversed(handles):unmount(view)
                    cleanup(batch)
            case['lowerAfter']=stats(lower)
            assert case['lowerAfter']==lower_stats
            report['cases'].append(case)
            cleanup(case_root)
        report['finishedAt']=utc();report['childUsage']=resource.getrusage(resource.RUSAGE_CHILDREN)._asdict() if hasattr(resource.getrusage(resource.RUSAGE_CHILDREN),'_asdict') else {'userSeconds':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime,'systemSeconds':resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,'maxRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
        return report
    finally:
        for view in list(reversed(mounted)):
            try:unmount(view)
            except Exception:pass

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--child':
        print(json.dumps(child(pathlib.Path(sys.argv[2]),sys.argv[3],sys.argv[4]),indent=2));sys.exit(0)
    output_root=pathlib.Path('/tmp/rudder-phase0-linux-evidence')
    data_root=pathlib.Path(tempfile.mkdtemp(prefix='.rudder-phase0-data-',dir='/workspace'))
    parent_ns={name:os.readlink('/proc/self/ns/'+name) for name in ['mnt','user']}
    repo=pathlib.Path('/workspace/code/exla-ai-rudder')
    meta={'startedAt':utc(),'uname':platform.uname()._asdict(),'uid':os.getuid(),'gid':os.getgid(),'node':command(['node','--version']),'python':sys.version,'git':command(['git','--version']),'jj':command(['jj','--version']),'sourceRevisionStart':command(['git','rev-parse','HEAD'],cwd=repo),'packageVersionStart':json.loads((repo/'package.json').read_text())['version'],'workingTreeStatusStart':command(['git','status','--porcelain'],cwd=repo),'hostCpuCountReported':os.cpu_count(),'cpuModel':next((line.split(':',1)[1].strip() for line in pathlib.Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),'unknown'),'cgroup':{name:(pathlib.Path('/sys/fs/cgroup')/name).read_text().strip() for name in ['cpu.max','memory.max'] if (pathlib.Path('/sys/fs/cgroup')/name).exists()},'regionEnv':os.environ.get('FLY_REGION'),'parentNamespace':parent_ns,'fixtureFilesystem':command(['stat','-f','-c','%T',str(data_root)]),'fixtureMountType':command(['findmnt','-n','-o','FSTYPE','-T',str(data_root)]),'scriptSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'buildScriptSha256':hashlib.sha256(NODE_BUILD.encode()).hexdigest(),'cacheState':'Warm local filesystem/page cache after fixture creation and one prepared build. No eviction. New Node process for every command.','loadAverageStart':os.getloadavg()}
    try:
        args=['unshare','--user','--map-root-user','--mount','--propagation','private','--',sys.executable,__file__,'--child',str(data_root),parent_ns['mnt'],parent_ns['user']]
        start=time.perf_counter_ns();run=subprocess.run(args,capture_output=True,text=True,timeout=120)
        (output_root/'raw-child.json').write_text(run.stdout)
        (output_root/'child-stderr.txt').write_text(run.stderr)
        meta.update({'childExitCode':run.returncode,'childTotalMs':(time.perf_counter_ns()-start)/1e6,'sourceRevisionEnd':command(['git','rev-parse','HEAD'],cwd=repo),'packageVersionEnd':json.loads((repo/'package.json').read_text())['version'],'parentNamespaceAfter':{name:os.readlink('/proc/self/ns/'+name) for name in ['mnt','user']},'hostSeesMount':any(os.path.ismount(path) for path in data_root.rglob('view')),'loadAverageEnd':os.getloadavg(),'finishedAt':utc()})
        if run.returncode:print(run.stderr,file=sys.stderr)
        else:
            report=json.loads(run.stdout)
            for case in report['cases']:
                print(case['name'],case['lower'])
                for count in [1,10]:
                    rows=[row for row in case['samples'] if row['views']==count]
                    print('views',count,{key:{'n':len(rows),'median':statistics.median(row[key] for row in rows),'min':min(row[key] for row in rows),'max':max(row[key] for row in rows),'samples':[row[key] for row in rows]} for key in ['createMs','firstReadMs','firstBuildMs','editedBuildMs']})
    finally:
        cleanup(data_root)
        meta['fixtureCleanupComplete']=not data_root.exists()
        (output_root/'provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
