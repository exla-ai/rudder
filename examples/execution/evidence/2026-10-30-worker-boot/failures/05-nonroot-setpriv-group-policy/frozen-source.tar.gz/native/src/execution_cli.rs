//! Early, fresh-process dispatch; PTY carries agent bytes, never a JSON spec.
use anyhow::{bail, Result};
#[cfg(target_os = "linux")]
use anyhow::{ensure, Context};
#[cfg(target_os = "linux")]
use rudder_engine::{
    execution::{ExecutionSpec, HelperServices, HelperServicesFactory},
    vfs::rpc::{AttemptAuthority, ObservationBinding},
};
#[cfg(target_os = "linux")]
use std::sync::Arc;

#[cfg(target_os = "linux")]
struct WorkspaceAuthority {
    broker: crate::agent_broker::BrokerClient,
    binding: ObservationBinding,
}
#[cfg(target_os = "linux")]
impl AttemptAuthority for WorkspaceAuthority {
    fn validate(&self, binding: &ObservationBinding) -> Result<()> {
        ensure!(
            binding == &self.binding,
            "workspace authority belongs to another exact execution"
        );
        self.broker.authorize_workspace(binding)
    }
}
#[cfg(target_os = "linux")]
fn services_factory() -> HelperServicesFactory {
    Box::new(|spec: &ExecutionSpec| {
        // The engine invokes this only after single-thread namespace entry.
        // No journal, caller-supplied author, or peer credential path is used.
        let workspace = spec
            .workspace_observation
            .as_ref()
            .context("workspace profile absent")?;
        let directory = spec
            .broker_directory
            .as_ref()
            .context("scoped broker projection absent")?;
        let expected = spec
            .broker_binding
            .as_ref()
            .context("sealed broker binding absent")?;
        let expected = crate::agent_broker::BrokerBinding {
            project_id: expected.project_id.clone(),
            run_id: expected.run_id.clone(),
            run_epoch: expected.run_epoch,
            owner_epoch: expected.owner_epoch,
        };
        let broker = crate::agent_broker::BrokerClient::connect_workspace(
            directory.join("broker.sock"),
            directory.join("identity.json"),
            &expected,
            &workspace.binding,
        )?;
        Ok(HelperServices {
            workspace_authority: Arc::new(WorkspaceAuthority {
                broker,
                binding: workspace.binding.clone(),
            }),
            adoption_witness: None,
        })
    })
}
pub(crate) fn run(args: &[String]) -> Result<()> {
    if args.first().is_some_and(|a| a == "capabilities") {
        println!("{}", rudder_engine::execution::capabilities());
        return Ok(());
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = args;
        bail!("restricted execution requires a qualified Linux worker");
    }
    #[cfg(target_os = "linux")]
    {
        if args.len() == 1 && args[0] == "child" {
            rudder_engine::execution::linux::run_child()?;
            return Ok(());
        }
        if args.len() != 5
            || args[0] != "helper"
            || args[1] != "--handoff"
            || args[3] != "--parent-pid"
        {
            bail!("execution helper requires its one-use parent descriptor handoff")
        }
        let spec = rudder_engine::execution::handoff::receive(&args[2], args[4].parse()?)?;
        let outcome = if spec.workspace_observation.is_some() {
            rudder_engine::execution::run_helper_with_services(spec, services_factory())?
        } else {
            rudder_engine::execution::run_helper(spec)?
        };
        // Protected execution record carries proof; never corrupt PTY bytes.
        std::process::exit(outcome.record.agent_exit.unwrap_or(125));
    }
}
