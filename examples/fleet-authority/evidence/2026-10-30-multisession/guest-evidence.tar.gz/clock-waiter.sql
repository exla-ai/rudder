BEGIN; SET LOCAL lock_timeout='3s'; SET LOCAL statement_timeout='4s'; INSERT INTO q_results(label,receipt) VALUES('clock-waiter',q_renew('clock','a','boot-a',2,0,'clock-renew')); COMMIT;
