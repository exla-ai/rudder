import { counter, fail, text, type OwnerGrant } from "./types.js";

/** One process/boot only. Call fence() on restart/resume uncertainty; it is irreversible. */
export class MonotonicLeaseFence {
  #pending?: { requestId: string; firstSent: number };
  #deadline = -Infinity;
  #serial = -1n;
  #fenced = false;
  constructor(readonly identity: { authorityId: string; accountId: string; projectId: string; engineInstanceId: string; machineBootId: string; ownerEpoch: string; leaseId: string }, readonly safety: { marginMs: number; engineRateError: number; databaseRateError: number; maxPositiveClockStepMs: number }) {
    if (Object.values(safety).some(value => !Number.isFinite(value) || value < 0) || safety.engineRateError >= 1 || safety.databaseRateError >= 1) fail("invalid_request");
    this.identity = Object.freeze({ ...identity }); this.safety = Object.freeze({ ...safety });
  }
  begin(requestId: string, now: number): void {
    text(requestId); if (this.#fenced || !Number.isFinite(now) || now < 0) fail("stale_fence");
    if (this.#pending && this.#pending.requestId !== requestId) fail("busy");
    this.#pending ??= { requestId, firstSent: now };
  }
  observe(grant: OwnerGrant, now: number): boolean {
    if (this.#serial >= 0n && now >= this.#deadline) this.fence();
    if (this.#fenced || !this.#pending || grant.requestId !== this.#pending.requestId || !Number.isFinite(now) || now < this.#pending.firstSent) return false;
    if (Object.entries(this.identity).some(([key, value]) => grant[key as keyof OwnerGrant] !== value)) return false;
    const serial = BigInt(counter(grant.renewalSerial));
    if (serial <= this.#serial || !Number.isFinite(grant.durationMs) || grant.durationMs <= 0 || grant.durationMs > 15000) return false;
    const duration = (grant.durationMs - this.safety.maxPositiveClockStepMs) * (1 - this.safety.engineRateError)
      / (1 + this.safety.databaseRateError) - this.safety.marginMs;
    const deadline = this.#pending.firstSent + duration;
    this.#pending = undefined;
    if (duration <= 0 || deadline <= now) { this.fence(); return false; }
    this.#deadline = deadline; this.#serial = serial; return true;
  }
  current(now: number): boolean {
    if (this.#serial < 0n && !this.#fenced) return false;
    if (!Number.isFinite(now) || now >= this.#deadline) this.fence();
    return !this.#fenced;
  }
  fence(): void { this.#fenced = true; this.#pending = undefined; this.#deadline = -Infinity; }
}
