# jj 0.40 factory qualification prototype

This is a separate, unpublished real jj CLI extension. It registers a distinct
`rudder-prototype-local-v1` working-copy factory and the explicit `rudder-init`
command, retaining jj-cli's ordinary dispatcher. The wrapper adapts jj's
Apache-2.0 custom-working-copy example. jj-cli and jj-lib are exact `=0.40.0`
registry dependencies with a supplied lockfile in this prototype artifact.
Their 289 distributed `src/` files match upstream commit
`941d0290f5511db1d1cf8e4fe7365ba7d1828ea0` byte for byte.

## Scope

`PrototypeWorkingCopy` delegates to `LocalWorkingCopy`. Snapshots still scan
source; checkouts still perform ordinary filesystem updates. The trace in private
`.jj/working_copy/rudder-prototype.log` exposes these calls. This is an API and
history/conflict compatibility proof, not a VFS/live snapshot implementation,
CoW fork benchmark, multi-host result, guest access-control proof or publication
protocol. Source/metadata setup uses eager private copies. No shared mutable
`.jj`, Git refs/index/config, source cache, CAS, journal or capability store is
mounted by the fixture. The Linux fixture inherits the host filesystem namespace
before making it private; it does not construct a restricted execution guest.

## Reproduce

Use an existing Rust toolchain plus Python 3, Git, and stock jj 0.40.0. Put this
whole directory on a filesystem with sufficient space. Cargo targets, temporary
files, fixture metadata and source stay beneath it. The first compile can use
about 1.2 GiB for the target directory; the controlled fixtures are small.

```sh
mkdir -p tmp
TMPDIR="$PWD/tmp" CARGO_TARGET_DIR="$PWD/target" cargo build --locked
python3 tests/run-linux.py --stock-jj /path/to/stock-jj
```

The Linux runner requires already-permitted unprivileged user/mount namespaces.
It creates a NEW namespace, makes propagation private, binds only the disposable
Git object seed read-only and proves a write returns `EROFS`. It never mounts in
the caller namespace or over a user checkout. Mounts disappear on exit. No
privilege escalation, package install or host mount is needed. To run the
portable non-kernel-enforced fallback, use `python3 tests/qualify.py`; the report
labels this as mode-only/integrity checking. macOS runtime behavior is untested.

Six tests exercise registered-type rejection by stock jj, native
status/diff/new/describe/edit/restore, executable/symlink/ignore behavior,
private object/ref/operation state, ordinary Git commit import, conflict
export/import into fresh stock jj with exact materialized markers/labels, and
preservation of legacy change IDs through private extra metadata. Each test
forks two private attempts from the same prepared template/object seed. Shared
seed and template hashes must remain unchanged. A separate Git-only import
control deliberately demonstrates legacy change-ID loss without extra metadata.

The Git-version test adapts its expected fetch result to the selected Git.
On the inspected Git 2.39.5, local commands and local-bare push pass, while jj's
fetch returns unsupported `--porcelain` plus `git >= 2.41.0` guidance. No global
Git version changes or network Git remotes are involved. Official upstream
minimum remains 2.41.0; these limited older-Git successes are not full support.

## Evidence

`report.json` records 6/6 passed, raw command argv/stdout/stderr and timings
(9.591 seconds total on the inspected Linux host). This is qualification time,
not a launch/cache benchmark. `provenance.json` records compiler, platform,
crate checksums, upstream source comparisons and source/lock/report hashes.
Upstream's declared Rust MSRV is 1.89; this build used rustc 1.99.1. The active
locked dependencies declare no newer MSRV, but a Rust 1.89 build was not run.
Only Git features are enabled; Watchman is absent. `qualification-final.log`
and `features.log` preserve the test and feature summaries. Fixture reports and
scripts contain only controlled test data, never provider credentials.

Root-workspace integration and a production working-copy type require a separate
review. Do not put this prototype on a real user's PATH or interpret existing
`local` metadata as this type. A true Rudder factory must replace local snapshot
and checkout calls with the fenced per-attempt VFS protocol and sealed projection
publication described in `docs/architecture/vcs-bridge.md`.
