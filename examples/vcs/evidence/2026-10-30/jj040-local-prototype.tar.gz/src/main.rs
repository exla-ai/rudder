// Copyright 2023 The Jujutsu Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::path::Path;
use std::path::PathBuf;
use std::sync::Arc;

use async_trait::async_trait;
use jj_cli::cli_util::CliRunner;
use jj_cli::cli_util::CommandHelper;
use jj_cli::command_error::CommandError;
use jj_cli::ui::Ui;
use jj_lib::backend::Backend;
use jj_lib::commit::Commit;
use jj_lib::git_backend::GitBackend;
use jj_lib::local_working_copy::LocalWorkingCopy;
use jj_lib::merged_tree::MergedTree;
use jj_lib::op_store::OperationId;
use jj_lib::ref_name::WorkspaceName;
use jj_lib::ref_name::WorkspaceNameBuf;
use jj_lib::repo::ReadonlyRepo;
use jj_lib::repo_path::RepoPathBuf;
use jj_lib::settings::UserSettings;
use jj_lib::signing::Signer;
use jj_lib::store::Store;
use jj_lib::working_copy::CheckoutError;
use jj_lib::working_copy::CheckoutStats;
use jj_lib::working_copy::LockedWorkingCopy;
use jj_lib::working_copy::ResetError;
use jj_lib::working_copy::SnapshotError;
use jj_lib::working_copy::SnapshotOptions;
use jj_lib::working_copy::SnapshotStats;
use jj_lib::working_copy::WorkingCopy;
use jj_lib::working_copy::WorkingCopyFactory;
use jj_lib::working_copy::WorkingCopyStateError;
use jj_lib::workspace::WorkingCopyFactories;
use jj_lib::workspace::Workspace;
use jj_lib::workspace::WorkspaceInitError;

#[derive(clap::Parser, Clone, Debug)]
enum PrototypeCommand {
    /// Initialize private colocated metadata with the prototype working-copy type.
    RudderInit,
}

async fn run_prototype_command(
    ui: &mut Ui,
    command_helper: &CommandHelper,
    command: PrototypeCommand,
) -> Result<(), CommandError> {
    match command {
        PrototypeCommand::RudderInit => {
            let wc_path = command_helper.cwd();
            let settings = command_helper.settings_for_new_workspace(ui, wc_path)?.0;
            let backend_initializer = |settings: &UserSettings, store_path: &Path| {
                // Relative to .jj/repo/store, so a sanitized template is relocatable.
                let backend: Box<dyn Backend> = Box::new(GitBackend::init_colocated(
                    settings,
                    store_path,
                    Path::new("../../.."),
                )?);
                Ok(backend)
            };
            Workspace::init_with_factories(
                &settings,
                wc_path,
                &backend_initializer,
                Signer::from_settings(&settings).map_err(WorkspaceInitError::SignInit)?,
                &ReadonlyRepo::default_op_store_initializer(),
                &ReadonlyRepo::default_op_heads_store_initializer(),
                &ReadonlyRepo::default_index_store_initializer(),
                &ReadonlyRepo::default_submodule_store_initializer(),
                &PrototypeWorkingCopyFactory,
                WorkspaceName::DEFAULT.to_owned(),
            )
            .await?;
            Ok(())
        }
    }
}

fn main() -> std::process::ExitCode {
    let mut factories = WorkingCopyFactories::new();
    factories.insert(
        PrototypeWorkingCopy::type_name().to_owned(),
        Box::new(PrototypeWorkingCopyFactory),
    );
    CliRunner::init()
        .name("jj")
        .version("0.40.0-rudder-prototype-local-v1")
        .add_working_copy_factories(factories)
        .add_subcommand(run_prototype_command)
        .run()
        .into()
}

/// API/compatibility prototype only. Delegating to LocalWorkingCopy still scans
/// source and performs real filesystem checkout. No VFS/live checkpoint claim.
struct PrototypeWorkingCopy {
    inner: Box<dyn WorkingCopy>,
    state_path: PathBuf,
}

impl PrototypeWorkingCopy {
    fn type_name() -> &'static str {
        "rudder-prototype-local-v1"
    }

    fn init(
        store: Arc<Store>,
        working_copy_path: PathBuf,
        state_path: PathBuf,
        operation_id: OperationId,
        workspace_name: WorkspaceNameBuf,
        settings: &UserSettings,
    ) -> Result<Self, WorkingCopyStateError> {
        let inner = LocalWorkingCopy::init(
            store,
            working_copy_path,
            state_path.clone(),
            operation_id,
            workspace_name,
            settings,
        )?;
        trace(&state_path, "init");
        Ok(Self {
            inner: Box::new(inner),
            state_path,
        })
    }

    fn load(
        store: Arc<Store>,
        working_copy_path: PathBuf,
        state_path: PathBuf,
        settings: &UserSettings,
    ) -> Result<Self, WorkingCopyStateError> {
        let inner = LocalWorkingCopy::load(store, working_copy_path, state_path.clone(), settings)?;
        trace(&state_path, "load");
        Ok(Self {
            inner: Box::new(inner),
            state_path,
        })
    }
}

// Best-effort prototype-only instrumentation in private metadata, never source.
fn trace(state_path: &Path, event: &str) {
    use std::io::Write;
    if let Ok(mut file) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(state_path.join("rudder-prototype.log"))
    {
        let _ = writeln!(file, "{} {event}", std::process::id());
    }
}

impl WorkingCopy for PrototypeWorkingCopy {
    fn name(&self) -> &str {
        Self::type_name()
    }
    fn workspace_name(&self) -> &WorkspaceName {
        self.inner.workspace_name()
    }
    fn operation_id(&self) -> &OperationId {
        self.inner.operation_id()
    }
    fn tree(&self) -> Result<&MergedTree, WorkingCopyStateError> {
        self.inner.tree()
    }
    fn sparse_patterns(&self) -> Result<&[RepoPathBuf], WorkingCopyStateError> {
        self.inner.sparse_patterns()
    }
    fn start_mutation(&self) -> Result<Box<dyn LockedWorkingCopy>, WorkingCopyStateError> {
        let inner = self.inner.start_mutation()?;
        trace(&self.state_path, "start_mutation");
        Ok(Box::new(LockedPrototypeWorkingCopy {
            inner,
            state_path: self.state_path.clone(),
        }))
    }
}

struct PrototypeWorkingCopyFactory;

impl WorkingCopyFactory for PrototypeWorkingCopyFactory {
    fn init_working_copy(
        &self,
        store: Arc<Store>,
        working_copy_path: PathBuf,
        state_path: PathBuf,
        operation_id: OperationId,
        workspace_name: WorkspaceNameBuf,
        settings: &UserSettings,
    ) -> Result<Box<dyn WorkingCopy>, WorkingCopyStateError> {
        Ok(Box::new(PrototypeWorkingCopy::init(
            store,
            working_copy_path,
            state_path,
            operation_id,
            workspace_name,
            settings,
        )?))
    }
    fn load_working_copy(
        &self,
        store: Arc<Store>,
        working_copy_path: PathBuf,
        state_path: PathBuf,
        settings: &UserSettings,
    ) -> Result<Box<dyn WorkingCopy>, WorkingCopyStateError> {
        Ok(Box::new(PrototypeWorkingCopy::load(
            store,
            working_copy_path,
            state_path,
            settings,
        )?))
    }
}

struct LockedPrototypeWorkingCopy {
    inner: Box<dyn LockedWorkingCopy + Send>,
    state_path: PathBuf,
}

#[async_trait]
impl LockedWorkingCopy for LockedPrototypeWorkingCopy {
    fn old_operation_id(&self) -> &OperationId {
        self.inner.old_operation_id()
    }
    fn old_tree(&self) -> &MergedTree {
        self.inner.old_tree()
    }
    async fn snapshot(
        &mut self,
        options: &SnapshotOptions,
    ) -> Result<(MergedTree, SnapshotStats), SnapshotError> {
        trace(&self.state_path, "snapshot_local_scan");
        self.inner.snapshot(options).await
    }
    async fn check_out(&mut self, commit: &Commit) -> Result<CheckoutStats, CheckoutError> {
        trace(&self.state_path, "checkout_local_files");
        self.inner.check_out(commit).await
    }
    fn rename_workspace(&mut self, new_name: WorkspaceNameBuf) {
        self.inner.rename_workspace(new_name);
    }
    async fn reset(&mut self, commit: &Commit) -> Result<(), ResetError> {
        trace(&self.state_path, "reset_metadata");
        self.inner.reset(commit).await
    }
    async fn recover(&mut self, commit: &Commit) -> Result<(), ResetError> {
        trace(&self.state_path, "recover_metadata");
        self.inner.recover(commit).await
    }
    fn sparse_patterns(&self) -> Result<&[RepoPathBuf], WorkingCopyStateError> {
        self.inner.sparse_patterns()
    }
    async fn set_sparse_patterns(
        &mut self,
        new_sparse_patterns: Vec<RepoPathBuf>,
    ) -> Result<CheckoutStats, CheckoutError> {
        trace(&self.state_path, "sparse_local_files");
        self.inner.set_sparse_patterns(new_sparse_patterns).await
    }
    async fn finish(
        self: Box<Self>,
        operation_id: OperationId,
    ) -> Result<Box<dyn WorkingCopy>, WorkingCopyStateError> {
        let inner = self.inner.finish(operation_id).await?;
        trace(&self.state_path, "finish");
        Ok(Box::new(PrototypeWorkingCopy {
            inner,
            state_path: self.state_path,
        }))
    }
}
