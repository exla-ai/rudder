#!/usr/bin/env python3
"""Run qualification in a new user/mount namespace with a read-only object seed."""

import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
namespace = os.readlink("/proc/self/ns/mnt")
raise SystemExit(subprocess.call([
    "unshare", "--user", "--map-root-user", "--mount", "--fork",
    sys.executable, str(root / "tests/qualify.py"),
    "--parent-mount-namespace", namespace, *sys.argv[1:],
]))
