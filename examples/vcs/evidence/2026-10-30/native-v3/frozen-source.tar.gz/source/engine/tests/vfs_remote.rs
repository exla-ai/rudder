use anyhow::{bail, Context, Result};
use rudder_engine::{
    content::{FileNode, CHUNK_BYTES, FILE_LAYOUT},
    directory::{self, DirectoryEntry, DirectoryStore, EntryNode, PagedDirectory},
    protocol::{canonical_json, CheckpointConsistency, ObjectKind, ObjectRef, OwnerEpoch},
    remote_cache::{CacheLimits, CacheScope, FetchControl, ImmutableObjectSource, RemoteCache},
    remote_root::{
        AttemptBinding, CurrentAttemptAuthority, RemoteRootRegistry, RemoteSession, RootBinding,
        RootLimits, RootReceiptSource,
    },
    remote_source::{
        ReplicatedDurability, ReplicatedRootReceipt, SourceError, SourceRequestControl,
    },
    snapshot::{RunnableRoot, SourceV2},
    store::{ImportPolicy, LocalStore},
    vfs::{self, NodeKind, ObservationBudget, RemoteOptions, VfsManager, VfsView},
    workspace::WorkspaceProfile,
};
use std::{
    collections::BTreeMap,
    fs,
    io::Write,
    os::unix::fs::PermissionsExt,
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicBool, AtomicUsize, Ordering},
        Arc, Mutex,
    },
    time::{Duration, Instant},
};
use tempfile::TempDir;
use uuid::Uuid;

fn serial() -> std::sync::MutexGuard<'static, ()> {
    static LOCK: Mutex<()> = Mutex::new(());
    LOCK.lock().unwrap_or_else(|error| error.into_inner())
}
fn temp() -> TempDir {
    let base = std::env::var_os("RUDDER_TEST_TMPDIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            if Path::new("/workspace").is_dir() {
                PathBuf::from("/workspace")
            } else {
                std::env::temp_dir()
            }
        });
    let result = tempfile::tempdir_in(base).unwrap();
    fs::set_permissions(result.path(), fs::Permissions::from_mode(0o700)).unwrap();
    result
}
struct Authority(AtomicBool);
impl CurrentAttemptAuthority for Authority {
    fn validate(&self, _attempt: &AttemptBinding, _root: &RootBinding) -> Result<()> {
        if self.0.load(Ordering::Acquire) {
            bail!("private authority fence")
        };
        Ok(())
    }
}
struct Source {
    scope: CacheScope,
    objects: Mutex<BTreeMap<ObjectRef, Vec<u8>>>,
    root: Mutex<Option<ReplicatedRootReceipt>>,
    calls: Mutex<Vec<ObjectRef>>,
    root_calls: AtomicUsize,
    fail: AtomicBool,
}
impl Source {
    fn new() -> Arc<Self> {
        Arc::new(Self {
            scope: CacheScope {
                provider_id: "vfs-remote-fixture".into(),
                tenant_id: Uuid::new_v4().to_string(),
            },
            objects: Mutex::new(BTreeMap::new()),
            root: Mutex::new(None),
            calls: Mutex::new(Vec::new()),
            root_calls: AtomicUsize::new(0),
            fail: AtomicBool::new(false),
        })
    }
    fn put(&self, kind: ObjectKind, bytes: &[u8]) -> ObjectRef {
        let reference = ObjectRef::from_bytes(kind, bytes);
        self.objects
            .lock()
            .unwrap()
            .insert(reference.clone(), bytes.to_vec());
        reference
    }
    fn metadata<T: serde::Serialize>(&self, kind: ObjectKind, value: &T) -> ObjectRef {
        self.put(kind, &canonical_json(value).unwrap())
    }
    fn publish_fixture(&self, root: &ObjectRef) {
        let objects = self.objects.lock().unwrap();
        *self.root.lock().unwrap() = Some(ReplicatedRootReceipt {
            format_version: 1,
            root_id: "prepared".into(),
            root: root.clone(),
            durability: ReplicatedDurability::Replicated,
            published_at_ms: 1,
            object_count: objects.len() as u64,
            total_bytes: objects.values().map(|value| value.len() as u64).sum(),
        });
    }
}
impl DirectoryStore for Source {
    fn read(&self, r: &ObjectRef) -> Result<Vec<u8>> {
        self.objects
            .lock()
            .unwrap()
            .get(r)
            .cloned()
            .context("missing fixture object")
    }
    fn put(&self, kind: ObjectKind, bytes: &[u8]) -> Result<ObjectRef> {
        directory::references_from_bytes(kind, bytes)?;
        Ok(Source::put(self, kind, bytes))
    }
}
impl ImmutableObjectSource for Source {
    fn scope(&self) -> CacheScope {
        self.scope.clone()
    }
    fn fetch(
        &self,
        reference: &ObjectRef,
        control: &FetchControl,
        output: &mut dyn Write,
    ) -> Result<()> {
        self.calls.lock().unwrap().push(reference.clone());
        if self.fail.load(Ordering::Acquire) {
            bail!("provider unavailable")
        };
        let bytes = DirectoryStore::read(self, reference)?;
        for part in bytes.chunks(65536) {
            control.check()?;
            output.write_all(part)?;
        }
        Ok(())
    }
}
impl RootReceiptSource for Source {
    fn scope(&self) -> CacheScope {
        self.scope.clone()
    }
    fn get_root(
        &self,
        _id: &str,
        _control: &SourceRequestControl,
    ) -> std::result::Result<ReplicatedRootReceipt, SourceError> {
        self.root_calls.fetch_add(1, Ordering::AcqRel);
        if self.fail.load(Ordering::Acquire) {
            return Err(SourceError::RemoteFailed);
        }
        self.root
            .lock()
            .unwrap()
            .clone()
            .ok_or(SourceError::RemoteFailed)
    }
}
struct Graph {
    source: Arc<Source>,
    root: ObjectRef,
    directory: ObjectRef,
    file: ObjectRef,
    chunks: Vec<ObjectRef>,
    large_name: Vec<u8>,
}
fn wrap(source: &Source, directory: &ObjectRef, topology: serde_json::Value) -> ObjectRef {
    let policy = source.put(ObjectKind::Blob, b"{}");
    let profile = source.metadata(ObjectKind::Blob, &WorkspaceProfile::source_only());
    let hardlinks = source.metadata(ObjectKind::Blob, &topology);
    let source_root = source.metadata(
        ObjectKind::SourceRoot,
        &SourceV2 {
            format_version: 2,
            consistency: CheckpointConsistency::Quiesced,
            directory: directory.clone(),
            projection_policy: policy,
        },
    );
    source.metadata(
        ObjectKind::RunnableRoot,
        &RunnableRoot {
            format_version: 1,
            consistency: CheckpointConsistency::Quiesced,
            source: source_root,
            environment: None,
            view_root: directory.clone(),
            profile,
            hardlinks,
            knowledge_cursor: u64::MAX,
        },
    )
}
fn graph(count: usize) -> Graph {
    let source = Source::new();
    let chunks = vec![
        source.put(ObjectKind::Blob, &vec![b'q'; CHUNK_BYTES]),
        source.put(ObjectKind::Blob, &vec![b'r'; CHUNK_BYTES]),
    ];
    let mut children = vec![chunks[0].clone(); 52];
    children[1] = chunks[1].clone();
    let file = source.metadata(
        ObjectKind::File,
        &FileNode {
            format_version: 1,
            layout: FILE_LAYOUT.into(),
            level: 0,
            logical_size: 52 * CHUNK_BYTES as u64,
            children,
        },
    );
    let nested_data = source.put(ObjectKind::Blob, b"nested");
    let nested = PagedDirectory::new(source.as_ref())
        .build(
            0o751,
            vec![DirectoryEntry::new(
                b"child",
                EntryNode::File {
                    object: nested_data.clone(),
                    logical_size: nested_data.size_bytes,
                    mode: 0o640,
                },
            )
            .unwrap()],
        )
        .unwrap();
    let mut entries = Vec::new();
    for index in 0..count {
        entries.push(
            DirectoryEntry::new(
                format!("file-{index:08}").as_bytes(),
                EntryNode::File {
                    object: file.clone(),
                    logical_size: 52 * CHUNK_BYTES as u64,
                    mode: 0o751,
                },
            )
            .unwrap(),
        );
    }
    entries.push(DirectoryEntry::new(b"dir", EntryNode::Directory { object: nested }).unwrap());
    entries.sort_by_key(|entry| entry.name().unwrap());
    let directory = PagedDirectory::new(source.as_ref())
        .build(0o755, entries)
        .unwrap();
    let root = wrap(
        &source,
        &directory,
        serde_json::json!({"format_version":1,"groups":[]}),
    );
    source.publish_fixture(&root);
    Graph {
        source,
        root,
        directory,
        file,
        chunks,
        large_name: format!("file-{:08}", count / 2).into_bytes(),
    }
}
fn attempt() -> AttemptBinding {
    AttemptBinding {
        project_id: "project".into(),
        run_id: Uuid::new_v4().to_string(),
        run_epoch: 1,
        owner: OwnerEpoch {
            owner: "remote-owner".into(),
            epoch: 7,
        },
        execution_id: Uuid::new_v4().to_string(),
        operation_id: Uuid::new_v4().to_string(),
        view_id: Uuid::new_v4().to_string(),
    }
}
fn session(registry: &RemoteRootRegistry, graph: &Graph) -> RemoteSession {
    registry
        .admit(
            &attempt(),
            "prepared",
            &graph.root,
            &SourceRequestControl::new(Instant::now() + Duration::from_secs(5)),
        )
        .unwrap()
}
struct Rig {
    _dir: TempDir,
    store: LocalStore,
    cache: RemoteCache,
    registry: RemoteRootRegistry,
    authority: Arc<Authority>,
    session: RemoteSession,
    manager: VfsManager,
    view: VfsView,
}
fn rig(graph: &Graph, options: RemoteOptions) -> Rig {
    let dir = temp();
    for name in ["cache", "registry"] {
        fs::create_dir(dir.path().join(name)).unwrap();
        fs::set_permissions(dir.path().join(name), fs::Permissions::from_mode(0o700)).unwrap();
    }
    let store = LocalStore::open(dir.path().join("local-cas")).unwrap();
    let cache = RemoteCache::open(
        dir.path().join("cache"),
        graph.source.clone(),
        CacheLimits {
            max_resident_bytes: 64 * 1024 * 1024,
            max_borrowed_bytes: 64 * 1024 * 1024,
            ..Default::default()
        },
    )
    .unwrap();
    let authority = Arc::new(Authority(AtomicBool::new(false)));
    let registry = RemoteRootRegistry::open(
        dir.path().join("registry"),
        cache.clone(),
        graph.source.clone(),
        authority.clone(),
        RootLimits {
            max_borrowed_bytes: 64 * 1024 * 1024,
            ..Default::default()
        },
    )
    .unwrap();
    let session = session(&registry, graph);
    let manager = VfsManager::open_remote(
        dir.path().join("manager"),
        store.clone(),
        session.clone(),
        &graph.root,
        options,
    )
    .unwrap();
    let view = manager.fork_remote().unwrap();
    Rig {
        _dir: dir,
        store,
        cache,
        registry,
        authority,
        session,
        manager,
        view,
    }
}
fn private_bytes(manager: &VfsManager, view: &VfsView) -> u64 {
    fs::read_dir(manager.root().join("views").join(view.id()).join("files"))
        .unwrap()
        .map(|entry| entry.unwrap().metadata().unwrap().len())
        .sum()
}

#[test]
fn remote_100k_fork_lookup_and_208mib_ranges_never_hydrate_or_pin_the_sdk() {
    let _serial = serial();
    let start = Instant::now();
    let graph = graph(99999);
    let fixture_ms = start.elapsed().as_millis();
    let start = Instant::now();
    let rig = rig(&graph, RemoteOptions::default());
    let launch_ms = start.elapsed().as_millis();
    assert_eq!(rig.view.descriptor().unwrap().inode_count, 1);
    assert_eq!(
        rig.view.descriptor().unwrap().data_plane.as_deref(),
        Some("remote_paged_ranges_v1")
    );
    assert!(rig.store.retention().unwrap().pins.is_empty());
    assert!(rig.store.read_object(&graph.directory).is_err());
    assert!(graph
        .source
        .calls
        .lock()
        .unwrap()
        .iter()
        .all(|reference| !graph.chunks.contains(reference)));
    let inode = rig.view.lookup(1, &graph.large_name).unwrap();
    assert_eq!(inode.size, 208 * 1024 * 1024);
    assert_ne!(inode.size, graph.file.size_bytes);
    assert_eq!(rig.view.read(inode.ino, 11, 7).unwrap(), b"qqqqqqq");
    assert_eq!(
        rig.view.read(inode.ino, CHUNK_BYTES as u64 + 5, 7).unwrap(),
        b"rrrrrrr"
    );
    let chunks = graph
        .source
        .calls
        .lock()
        .unwrap()
        .iter()
        .filter(|r| graph.chunks.contains(r))
        .count();
    assert_eq!(chunks, 2);
    assert!(rig.cache.stats().unwrap().disk_bytes < 9 * 1024 * 1024);
    assert_eq!(private_bytes(&rig.manager, &rig.view), 0);
    // Opening a directory does not scan it; bounded readdir reports its limit.
    let handle = rig.view.open_handle(1, libc::O_RDONLY, true).unwrap();
    assert_eq!(
        vfs::errno(&rig.view.directory_handle(1, handle).unwrap_err()),
        libc::EOVERFLOW
    );
    rig.view.close_handle(1, handle).unwrap();
    let before = rig.store.retention().unwrap();
    assert_eq!(
        vfs::errno(&rig.view.checkpoint_snapshot_unmounted().unwrap_err()),
        libc::EOPNOTSUPP
    );
    assert_eq!(vfs::errno(&rig.view.seal().unwrap_err()), libc::EOPNOTSUPP);
    assert_eq!(
        vfs::errno(
            &rig.view
                .observe_source(
                    &ImportPolicy::default(),
                    &Uuid::new_v4().to_string(),
                    &ObservationBudget::default()
                )
                .unwrap_err()
        ),
        libc::EOPNOTSUPP
    );
    let after = rig.store.retention().unwrap();
    assert_eq!(before.pins, after.pins);
    assert_eq!(before.staging, after.staging);
    rig.view.write(inode.ino, 11, b"changed", true).unwrap();
    assert_eq!(private_bytes(&rig.manager, &rig.view), 65536);
    eprintln!(
        "{}",
        serde_json::json!({"event":"logical-remote-vfs","entries":100000,"fixture_ms":fixture_ms,"constructor_and_fork_ms":launch_ms,"logical_file_bytes":inode.size,"chunk_fetches":chunks,"partial_cache_bytes":rig.cache.stats().unwrap().disk_bytes,"local_complete_pins":after.pins.len(),"private_copyup_bytes":private_bytes(&rig.manager,&rig.view)})
    );
}

#[test]
fn sibling_range_cow_runtime_links_unlink_and_origin_rename_survive_reopen() {
    let _serial = serial();
    let graph = graph(2);
    let rig = rig(&graph, RemoteOptions::default());
    let sibling_session = session(&rig.registry, &graph);
    let sibling_manager = VfsManager::open_remote(
        rig.manager.root(),
        rig.store.clone(),
        sibling_session,
        &graph.root,
        RemoteOptions::default(),
    )
    .unwrap();
    let sibling = sibling_manager.fork_remote().unwrap();
    let inode = rig.view.lookup(1, &graph.large_name).unwrap();
    rig.view.write(inode.ino, 11, b"changed", false).unwrap();
    assert_eq!(private_bytes(&rig.manager, &rig.view), 65536);
    let sibling_inode = sibling.lookup(1, &graph.large_name).unwrap();
    assert_eq!(sibling.read(sibling_inode.ino, 11, 7).unwrap(), b"qqqqqqq");
    assert_eq!(rig.view.read(inode.ino, 11, 7).unwrap(), b"changed");
    let directory = rig.view.lookup(1, b"dir").unwrap();
    rig.view.rename(1, b"dir", 1, b"renamed", 0).unwrap();
    let child = rig.view.lookup(directory.ino, b"child").unwrap();
    assert_eq!(rig.view.read(child.ino, 0, 6).unwrap(), b"nested");
    let private = rig
        .view
        .create(1, b"private", NodeKind::Directory, 0o700, b"")
        .unwrap();
    rig.view
        .rename(directory.ino, b"child", private.ino, b"moved", 0)
        .unwrap();
    rig.view.link(child.ino, 1, b"linked").unwrap();
    assert_eq!(rig.view.lookup(1, b"linked").unwrap().ino, child.ino);
    rig.view.unlink(private.ino, b"moved", false).unwrap();
    assert_eq!(rig.view.attr(child.ino).unwrap().nlink, 1);
    let handle = rig
        .view
        .open_handle(child.ino, libc::O_RDWR, false)
        .unwrap();
    rig.view.unlink(1, b"linked", false).unwrap();
    assert_eq!(rig.view.attr(child.ino).unwrap().nlink, 0);
    assert_eq!(rig.view.read(child.ino, 0, 6).unwrap(), b"nested");
    rig.view.close_handle(child.ino, handle).unwrap();
    let Rig {
        _dir,
        store,
        cache,
        registry,
        authority,
        session,
        manager,
        view,
    } = rig;
    drop(view);
    let view = manager.open_remote_view().unwrap();
    let inode = view.lookup(1, &graph.large_name).unwrap();
    assert_eq!(view.read(inode.ino, 11, 7).unwrap(), b"changed");
    assert_eq!(view.lookup(1, b"renamed").unwrap().ino, directory.ino);
    assert!(view.lookup(1, b"dir").is_err());
    assert!(store.retention().unwrap().pins.is_empty());
    drop((
        view,
        sibling,
        sibling_manager,
        session,
        manager,
        registry,
        authority,
        cache,
    ));
}

#[test]
fn stale_authority_blocks_private_and_inherited_operations_without_refetch() {
    let _serial = serial();
    let graph = graph(1);
    let rig = rig(&graph, RemoteOptions::default());
    let file = rig.view.lookup(1, &graph.large_name).unwrap();
    rig.view.write(file.ino, 0, b"private", true).unwrap();
    let before = graph.source.calls.lock().unwrap().len();
    rig.authority.0.store(true, Ordering::Release);
    rig.session.invalidate();
    assert_eq!(
        vfs::errno(&rig.view.read(file.ino, 0, 7).unwrap_err()),
        libc::ESTALE
    );
    assert_eq!(
        vfs::errno(&rig.view.write(file.ino, 0, b"x", true).unwrap_err()),
        libc::ESTALE
    );
    assert_eq!(
        vfs::errno(&rig.view.lookup(1, b"dir").unwrap_err()),
        libc::ESTALE
    );
    assert_eq!(graph.source.calls.lock().unwrap().len(), before);
}

#[test]
fn unavailable_provider_never_falls_back_to_arbitrary_local_cas_presence() {
    let _serial = serial();
    let graph = graph(1);
    let rig = rig(&graph, RemoteOptions::default());
    let file = rig.view.lookup(1, &graph.large_name).unwrap();
    let bytes = DirectoryStore::read(graph.source.as_ref(), &graph.chunks[0]).unwrap();
    assert_eq!(rig.store.put_blob(&bytes).unwrap(), graph.chunks[0]);
    graph.source.fail.store(true, Ordering::Release);
    assert_eq!(
        vfs::errno(&rig.view.read(file.ino, 11, 7).unwrap_err()),
        libc::EIO
    );
    assert_eq!(private_bytes(&rig.manager, &rig.view), 0);
    assert!(rig.store.retention().unwrap().pins.is_empty());
}

#[test]
fn actual_file_length_mismatch_fails_before_creating_an_inherited_inode() {
    let _serial = serial();
    let mut graph = graph(1);
    let directory = PagedDirectory::new(graph.source.as_ref())
        .build(
            0o755,
            vec![DirectoryEntry::new(
                b"wrong",
                EntryNode::File {
                    object: graph.file.clone(),
                    logical_size: 208 * 1024 * 1024 + 1,
                    mode: 0o644,
                },
            )
            .unwrap()],
        )
        .unwrap();
    graph.directory = directory;
    graph.root = wrap(
        graph.source.as_ref(),
        &graph.directory,
        serde_json::json!({"format_version":1,"groups":[]}),
    );
    graph.source.publish_fixture(&graph.root);
    let rig = rig(&graph, RemoteOptions::default());
    assert_eq!(
        vfs::errno(&rig.view.lookup(1, b"wrong").unwrap_err()),
        libc::EIO
    );
    assert_eq!(rig.view.descriptor().unwrap().inode_count, 1);
}

#[test]
fn cached_proofs_are_bounded_and_local_mode_cannot_reopen_a_partial_view() {
    let _serial = serial();
    let graph = graph(1000);
    let rig = rig(
        &graph,
        RemoteOptions {
            max_cached_objects: 4,
            max_cached_bytes: CHUNK_BYTES as u64,
            ..Default::default()
        },
    );
    assert_eq!(
        vfs::errno(&rig.manager.prepare(&graph.directory).unwrap_err()),
        libc::EOPNOTSUPP
    );
    assert_eq!(
        vfs::errno(&rig.manager.prepare_paged(&graph.directory).unwrap_err()),
        libc::EOPNOTSUPP
    );
    assert!(rig.store.retention().unwrap().pins.is_empty());
    for index in 0..20 {
        rig.view
            .lookup(1, format!("file-{index:08}").as_bytes())
            .unwrap();
        let stats = rig.manager.remote_stats().unwrap().unwrap();
        assert!(stats.cached_objects <= 4);
        assert!(stats.cached_encoded_bytes <= CHUNK_BYTES as u64);
    }
    let local = VfsManager::open(rig.manager.root(), rig.store.clone()).unwrap();
    let id = rig.view.id().to_string();
    let owner = rig.session.attempt().owner.clone();
    let Rig {
        _dir,
        store,
        cache,
        registry,
        authority,
        session,
        manager,
        view,
    } = rig;
    drop(view);
    assert_eq!(
        vfs::errno(&local.open_view(&id, &owner).err().unwrap()),
        libc::EOPNOTSUPP
    );
    let view = manager.open_remote_view().unwrap();
    assert_eq!(view.id(), id);
    drop((
        view, manager, local, session, registry, authority, cache, store,
    ));
}

#[test]
fn local_nonblocking_directory_open_defers_enumeration_but_ordinary_open_stays_eager() {
    let _serial = serial();
    let dir = temp();
    let store = LocalStore::open(dir.path().join("cas")).unwrap();
    let blob = store.put_blob(b"local").unwrap();
    let root = store
        .put_directory(rudder_engine::store::DirectoryManifest {
            format_version: 1,
            mode: 0o755,
            entries: [b"a", b"b"]
                .into_iter()
                .map(|name| {
                    rudder_engine::store::DirectoryEntry::new(
                        name,
                        rudder_engine::store::EntryNode::File {
                            object: blob.clone(),
                            mode: 0o644,
                        },
                    )
                    .unwrap()
                })
                .collect(),
        })
        .unwrap();
    let manager = VfsManager::open(dir.path().join("manager"), store).unwrap();
    manager.prepare_paged(&root).unwrap();
    let view = manager
        .fork_paged(&Uuid::new_v4().to_string(), &root, attempt().owner)
        .unwrap();
    let handle = view
        .open_handle(1, libc::O_RDONLY | libc::O_NONBLOCK, true)
        .unwrap();
    assert_eq!(view.descriptor().unwrap().inode_count, 1);
    assert_eq!(view.directory_handle(1, handle).unwrap().len(), 4);
    assert_eq!(view.descriptor().unwrap().inode_count, 3);
    view.close_handle(1, handle).unwrap();
    let view = manager
        .fork_paged(&Uuid::new_v4().to_string(), &root, attempt().owner)
        .unwrap();
    view.open_handle(1, libc::O_RDONLY, true).unwrap();
    assert_eq!(view.descriptor().unwrap().inode_count, 3);
}

#[test]
fn inherited_hardlink_topology_requires_explicit_bulk_and_bad_expected_root_is_rejected() {
    let _serial = serial();
    let mut graph = graph(2);
    graph.root = wrap(
        graph.source.as_ref(),
        &graph.directory,
        serde_json::json!({"format_version":1,"groups":[{"paths_hex":[[hex::encode(b"file-00000000")],[hex::encode(b"file-00000001")]]}]}),
    );
    graph.source.publish_fixture(&graph.root);
    let dir = temp();
    for name in ["cache", "registry"] {
        fs::create_dir(dir.path().join(name)).unwrap();
        fs::set_permissions(dir.path().join(name), fs::Permissions::from_mode(0o700)).unwrap();
    }
    let store = LocalStore::open(dir.path().join("cas")).unwrap();
    let cache = RemoteCache::open(
        dir.path().join("cache"),
        graph.source.clone(),
        CacheLimits::default(),
    )
    .unwrap();
    let registry = RemoteRootRegistry::open(
        dir.path().join("registry"),
        cache,
        graph.source.clone(),
        Arc::new(Authority(AtomicBool::new(false))),
        RootLimits::default(),
    )
    .unwrap();
    let session = session(&registry, &graph);
    let error = VfsManager::open_remote(
        dir.path().join("manager"),
        store.clone(),
        session.clone(),
        &graph.root,
        RemoteOptions::default(),
    )
    .err()
    .unwrap();
    assert_eq!(vfs::errno(&error), libc::EOPNOTSUPP);
    assert!(!dir.path().join("manager").exists());
    assert!(store.retention().unwrap().pins.is_empty());
    let mut different = graph.root.clone();
    different.digest = "a".repeat(64);
    assert!(VfsManager::open_remote(
        dir.path().join("wrong"),
        store,
        session,
        &different,
        RemoteOptions::default()
    )
    .is_err());
}
