//! Explicit retained-local launches. App owns reservation, result adoption and
//! PTYs; bounded workers own all materialization, credentials, grant and bind IO.
use super::*;
use crate::managed_launch::{ManagedLaunchFence, ManagedLocalLaunchInputs, ManagedRunSource};
use rudder_engine::journal::{Journal, OwnerFence};

#[cfg(target_os = "linux")]
mod local {
    use super::*;
    use crate::{agent_broker::{AgentBroker, BrokerConfig}, managed_launch::{self, PreparedManagedLaunch}};
    use rudder_engine::{execution::{handoff::{HandoffReceipt, ManagedExecutionHandoff, ManagedExecutionHandle, ManagedExecutionEvent}, ManagedShutdownReceipt, StopAndCheckpoint}, paths::FabricPaths};
    use std::sync::{atomic::{AtomicBool, AtomicUsize, Ordering}, Arc, mpsc::{self, Receiver, SyncSender}};
    use std::collections::BTreeMap;

    const MAX_PREPARATIONS: usize = 2;
    const PREPARATION_DEADLINE: Duration = Duration::from_secs(120);
    const STOP_DEADLINE: Duration = Duration::from_secs(30);
    fn now_ms() -> Result<i64> {
        Ok(std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)?.as_millis().try_into()?)
    }

    /// A timed-out/cancelled job retains its admission until actual settlement.
    /// The bounded result channel also retains admission if App falls behind.
    struct WorkerQueue<T> { active: Arc<AtomicUsize>, send: SyncSender<T>, receive: Receiver<T> }
    struct WorkerPermit(Arc<AtomicUsize>);
    impl Drop for WorkerPermit { fn drop(&mut self) { self.0.fetch_sub(1, Ordering::AcqRel); } }
    impl<T: Send + 'static> WorkerQueue<T> {
        fn new() -> Self { let (send, receive) = mpsc::sync_channel(MAX_PREPARATIONS);
            Self { active: Arc::new(AtomicUsize::new(0)), send, receive } }
        fn admit(&self) -> Result<WorkerPermit> {
            self.active.fetch_update(Ordering::AcqRel, Ordering::Acquire,
                |active| (active < MAX_PREPARATIONS).then_some(active + 1))
                .map_err(|_| anyhow::anyhow!("managed launch preparation is busy"))?;
            Ok(WorkerPermit(self.active.clone()))
        }
        fn spawn(&self, permit: WorkerPermit, waker: Option<PtyOutputWaker>, work: impl FnOnce(SyncSender<T>) -> T + Send + 'static) -> Result<()> {
            let send = self.send.clone();
            thread::Builder::new().name("rudder-managed-prepare".into()).spawn(move || {
                let _permit = permit;
                let result = work(send.clone());
                let _ = send.send(result);
                if let Some(waker) = waker { waker(); }
            })?;
            Ok(())
        }
    }

    struct Pending { fence: ManagedLaunchFence, cancelled: Arc<AtomicBool>, started: Instant }
    struct PreparedResult { prepared: PreparedManagedLaunch, broker: AgentBroker, projection_hash: [u8; 32],
        handoff: ManagedExecutionHandoff, native_program: PathBuf, launch_json: String }
    enum WorkerStep { Workspace { prepared: PreparedManagedLaunch, proceed: SyncSender<PreparedManagedLaunch> }, Ready(PreparedResult) }
    struct WorkerResult { fence: ManagedLaunchFence, result: Result<WorkerStep> }
    struct Live { prepared: PreparedManagedLaunch, handoff: HandoffReceipt, control: ManagedExecutionHandle,
        receipt: Option<ManagedShutdownReceipt>, stop: Option<(StopAndCheckpoint, Instant)>, uncertain: bool }

    pub(crate) struct ManagedAppState { queue: WorkerQueue<WorkerResult>, pending: BTreeMap<String, Pending>, live: BTreeMap<String, Live> }
    impl Default for ManagedAppState { fn default() -> Self { Self { queue: WorkerQueue::new(), pending: BTreeMap::new(), live: BTreeMap::new() } } }
    impl Drop for ManagedAppState { fn drop(&mut self) { for pending in self.pending.values() { pending.cancelled.store(true, Ordering::Release); } } }

    fn still_pending(app: &App, fence: &ManagedLaunchFence, owner: &OwnerFence) -> bool {
        owner == &fence.owner && app.agents.iter().any(|run| run.id == fence.run_id
            && run.terminal.is_none() && run.status == AgentStatus::Running
            && run.managed_local.as_ref().and_then(ManagedRunSource::fence) == Some(fence))
    }

    impl App {
        /// Explicit opt-in only. The caller supplies an existing stopped row and
        /// a retained local selection. No default/profile/cwd fallback exists.
        pub(crate) fn start_managed_local(&mut self, index: usize, inputs: ManagedLocalLaunchInputs,
            native_program: PathBuf, journal: &mut Journal, owner: &OwnerFence) -> Result<ManagedLaunchFence> {
            let run = self.agents.get(index).context("managed launch row is absent")?;
            anyhow::ensure!(run.terminal.is_none() && !matches!(run.status, AgentStatus::Running | AgentStatus::Merged | AgentStatus::Migrated)
                && run.managed_local.is_none() && run.session_id.is_none() && !run.plain_process
                && !run.is_main() && !run.is_orchestrator() && !is_cloud_owned_agent(run)
                && run.workspace_path.is_none() && run.jj_change_id.is_none(),
                "managed local launch requires a new explicitly selected row");
            anyhow::ensure!(run.backend == inputs.backend.backend() && native_program.is_absolute(), "managed backend/program selection differs from the row");
            anyhow::ensure!(inputs.journal == FabricPaths::new(&inputs.home).journal,
                "managed launch journal differs from its explicit identity home");
            anyhow::ensure!(journal.database_path()? == inputs.journal,
                "managed launch worker journal differs from App ownership");
            let permit = self.managed_local.queue.admit()?;
            let attempt_id = uuid::Uuid::new_v4().to_string();
            let request_id = uuid::Uuid::new_v4().to_string();
            let operation_id = uuid::Uuid::new_v4().to_string();
            let view_id = uuid::Uuid::new_v4().to_string();
            let run_id = run.id.clone();
            let epoch = journal.observe_run_attempt(owner, &run_id, &attempt_id, now_ms()?)?;
            let fence = ManagedLaunchFence { owner: owner.clone(), run_id: run_id.clone(), run_epoch: epoch, attempt_id, request_id };
            let source = ManagedRunSource::Reserved { fence: fence.clone(), runnable_root: inputs.runnable_root.clone() };
            source.validate(&run_id)?;
            let run = &mut self.agents[index];
            run.managed_local = Some(source); run.status = AgentStatus::Running;
            run.execution_profile = Some(inputs.backend.execution_profile().into());
            run.completed_at = None; run.last_error = Some("preparing managed local source".into());
            // This marker contains no credentials and must precede worker effects.
            // Managed persistence performs no Git/history queries.
            if let Err(error) = save_native_run_record(&self.cwd, run) {
                run.status = AgentStatus::Orphaned;
                return Err(error.context("persist managed reservation before preparation"));
            }
            let cancelled = Arc::new(AtomicBool::new(false));
            self.managed_local.pending.insert(run_id.clone(), Pending { fence: fence.clone(), cancelled: cancelled.clone(), started: Instant::now() });
            let request = inputs.bind(fence.clone(), operation_id, view_id);
            let worker_fence = fence.clone();
            let stage_waker = self.pty_output_waker.clone();
            let spawn = self.managed_local.queue.spawn(permit, self.pty_output_waker.clone(), move |events| {
                let result = (|| -> Result<PreparedResult> {
                    let home = request.home.clone(); let journal_path = request.journal.clone(); let backend = request.backend.backend();
                    let prepared = managed_launch::prepare_local(request, cancelled.clone())?;
                    let (proceed, receive) = mpsc::sync_channel(1);
                    events.send(WorkerResult { fence: worker_fence.clone(), result: Ok(WorkerStep::Workspace { prepared, proceed }) })
                        .map_err(|_|anyhow::anyhow!("managed App retired before workspace assignment"))?;
                    if let Some(waker) = &stage_waker { waker(); }
                    let prepared = receive.recv_timeout(PREPARATION_DEADLINE).context("managed assignment adoption did not settle")?;
                    anyhow::ensure!(!cancelled.load(Ordering::Acquire), "managed launch cancelled before grant");
                    let mut unused_command = TerminalCommand::with_args("", Vec::<String>::new());
                    let projection = fabric_runtime::prepare_agent_tools_for_attempt(&mut unused_command, backend, &home,
                        &worker_fence, Some(&prepared.assignment))?;
                    anyhow::ensure!(!cancelled.load(Ordering::Acquire), "managed launch cancelled before broker bind");
                    let broker = AgentBroker::spawn(BrokerConfig { journal_path: journal_path.clone(),
                        identity_file: projection.identity_file, socket_path: projection.broker_socket })?;
                    let handoff = prepared.prepare_handoff()?;
                    anyhow::ensure!(!cancelled.load(Ordering::Acquire), "managed launch cancelled before result");
                    worker_fence.check_current(&Journal::open(&journal_path)?)?;
                    let launch_json = serde_json::to_string(&prepared.link_launch())?;
                    Ok(PreparedResult { prepared, broker, projection_hash: projection.projection_hash, handoff, native_program, launch_json })
                })();
                WorkerResult { fence: worker_fence, result: result.map(WorkerStep::Ready) }
            });
            if let Err(error) = spawn {
                self.managed_local.pending.remove(&run_id);
                let run = &mut self.agents[index]; run.status = AgentStatus::Orphaned;
                run.last_error = Some("managed preparation worker could not start; reservation needs recovery".into());
                let _ = save_native_run_record(&self.cwd, run);
                return Err(error);
            }
            self.dirty = true;
            Ok(fence)
        }
    }

    pub(crate) fn poll(app: &mut App, journal: &mut Journal, owner: &OwnerFence) -> Result<()> {
        let mut state = std::mem::take(&mut app.managed_local);
        let result = state.poll(app, journal, owner);
        app.managed_local = state; result
    }
    impl ManagedAppState {
        fn poll(&mut self, app: &mut App, journal: &mut Journal, owner: &OwnerFence) -> Result<()> {
            for pending in self.pending.values() {
                if pending.started.elapsed() >= PREPARATION_DEADLINE || !still_pending(app, &pending.fence, owner)
                    || pending.fence.check_current(journal).is_err() {
                    pending.cancelled.store(true, Ordering::Release);
                    if let Some(run) = app.agents.iter_mut().find(|run|run.id == pending.fence.run_id
                        && run.managed_local.as_ref().and_then(ManagedRunSource::fence) == Some(&pending.fence)
                        && run.status == AgentStatus::Running) {
                        run.status = AgentStatus::Orphaned; run.last_error = Some("managed preparation cancelled/stale/timed out; no replacement launched".into());
                        let _ = save_native_run_record(&app.cwd, run); app.dirty = true;
                    }
                }
            }
            while let Ok(result) = self.queue.receive.try_recv() {
                let workspace_stage = matches!(&result.result, Ok(WorkerStep::Workspace { .. }));
                let exact = self.pending.get(&result.fence.run_id).is_some_and(|pending|pending.fence == result.fence
                    && !pending.cancelled.load(Ordering::Acquire));
                if !workspace_stage && self.pending.get(&result.fence.run_id).is_some_and(|pending|pending.fence == result.fence) {
                    self.pending.remove(&result.fence.run_id);
                }
                if !exact || !still_pending(app, &result.fence, owner) || result.fence.check_current(journal).is_err() { continue; }
                let index = app.agents.iter().position(|run|run.id == result.fence.run_id).unwrap();
                match result.result {
                    Ok(WorkerStep::Workspace { prepared, proceed }) => {
                        anyhow::ensure!(journal.database_path()? == prepared.identity_journal, "prepared workspace journal differs from App ownership");
                        app.agents[index].managed_local = Some(ManagedRunSource::Assigned { assignment: Box::new(prepared.assignment.clone()) });
                        if save_native_run_record(&app.cwd, &app.agents[index]).is_err() {
                            if let Some(pending) = self.pending.get(&result.fence.run_id) { pending.cancelled.store(true, Ordering::Release); }
                            orphan(&app.cwd, &mut app.agents[index], "managed assignment persistence failed; no capability was granted");
                        } else if proceed.try_send(prepared).is_err() {
                            orphan(&app.cwd, &mut app.agents[index], "managed assignment continuation retired; no helper was spawned");
                        }
                    }
                    Ok(WorkerStep::Ready(mut ready)) => {
                        anyhow::ensure!(journal.database_path()? == ready.prepared.identity_journal, "prepared helper journal differs from App ownership");
                        let assignment = ready.prepared.assignment.clone();
                        app.agents[index].managed_local = Some(ManagedRunSource::Assigned { assignment: Box::new(assignment.clone()) });
                        if save_native_run_record(&app.cwd, &app.agents[index]).is_err() {
                            orphan(&app.cwd, &mut app.agents[index], "managed assignment could not be persisted; helper was not spawned");
                            continue;
                        }
                        // A failed spawn/activation may still have created a child.
                        // From this point Drop cannot unpin/remove the live source.
                        ready.prepared.adopt();
                        let options = TerminalPaneOptions { size: app.agents[index].terminal_size.unwrap_or_default(),
                            cwd: None, ..TerminalPaneOptions::default() };
                        match TerminalPane::spawn_managed(ready.native_program.display().to_string(), ready.handoff,
                            &assignment.fence.attempt_id, &ready.prepared.execution_profile, Some(&ready.launch_json), options) {
                            Ok((mut terminal, handoff, control)) => {
                                App::attach_output_waker(&app.pty_output_waker, &terminal);
                                let adoption = app.fabric_runtime.adopt_managed_broker(owner, &assignment, &ready.prepared.identity_home,
                                    &mut terminal, ready.broker, ready.projection_hash);
                                if adoption.is_err() {
                                    terminal.request_termination();
                                    orphan(&app.cwd, &mut app.agents[index], "managed broker adoption failed after helper spawn; source retained for recovery");
                                } else {
                                    app.agents[index].terminal = Some(terminal);
                                    app.agents[index].last_error = None;
                                    self.live.insert(assignment.fence.run_id.clone(), Live { prepared: ready.prepared,
                                        handoff, control, receipt: None, stop: None, uncertain: false });
                                    let _ = save_native_run_record(&app.cwd, &app.agents[index]);
                                }
                            }
                            Err(_) => orphan(&app.cwd, &mut app.agents[index], "managed helper spawn/activation failed; source retained for recovery"),
                        }
                    }
                    Err(_) => orphan(&app.cwd, &mut app.agents[index], "managed local preparation failed; no checkout fallback was launched"),
                }
                app.dirty = true;
            }
            let ids: Vec<_> = self.live.keys().cloned().collect();
            for id in ids {
                let live = self.live.get_mut(&id).unwrap();
                let assignment = &live.prepared.assignment;
                let Some(index) = app.agents.iter().position(|run|run.id == id
                    && run.managed_local.as_ref().and_then(ManagedRunSource::fence) == Some(&assignment.fence)) else {
                    app.fabric_runtime.close(&id); self.live.remove(&id); continue;
                };
                if assignment.fence.owner != *owner || assignment.fence.check_current(journal).is_err() {
                    live.uncertain = true;
                }
                if let Some(Err(_)) = live.handoff.try_result() { live.uncertain = true; }
                while let Some(event) = live.control.try_event() {
                    match event {
                        ManagedExecutionEvent::BackendReady { process } if !live.uncertain && live.stop.is_none() => {
                            let expected = app.agents[index].session_id.clone();
                            if let Some(terminal) = app.agents[index].terminal.as_mut() {
                                if app.fabric_runtime.attach_managed_backend(owner, assignment, terminal, live.prepared.link_launch(),
                                    live.prepared.transport.guest_cwd.clone(), expected, process).is_err() { live.uncertain = true; }
                            } else { live.uncertain = true; }
                        }
                        ManagedExecutionEvent::Shutdown(receipt) => {
                            if live.stop.as_ref().is_some_and(|(request, _)| *request == receipt.request) && receipt.kernel_drained {
                                live.receipt = Some(receipt);
                            } else { live.uncertain = true; }
                        }
                        ManagedExecutionEvent::BackendReady { .. } => {}
                        ManagedExecutionEvent::Uncertain => live.uncertain = true,
                    }
                }
                if live.stop.as_ref().is_some_and(|(_, at)| at.elapsed() > STOP_DEADLINE) { live.uncertain = true; }
                let run = &mut app.agents[index];
                let exit = if let Some(terminal) = run.terminal.as_mut() {
                    if !terminal.drain_output().is_empty() { run.last_output_at = Instant::now(); app.dirty = true; }
                    let _ = terminal.take_notifications();
                    if live.uncertain { terminal.request_termination(); }
                    terminal.try_wait_after_output()
                } else { Ok(None) };
                if live.uncertain {
                    app.fabric_runtime.close(&id);
                    run.status = AgentStatus::Orphaned; run.completed_at = None;
                    run.last_error = Some("managed helper outcome is uncertain; no checkpoint acknowledged".into());
                    if !matches!(exit, Ok(None)) || run.terminal.is_none() {
                        run.terminal = None; self.live.remove(&id);
                    }
                    let _ = save_native_run_record(&app.cwd, run); app.dirty = true;
                } else if let Ok(Some(_)) = exit {
                    // The process reaper and private FD worker race to deliver
                    // their final events. Keep the owned terminal until the
                    // bounded stop deadline lets the receipt worker settle.
                    if live.stop.is_some() && live.receipt.is_none() { continue; }
                    // Physical exit alone never certifies final bytes. Even an
                    // observed completed model turn still needs the FD receipt.
                    let proved = live.receipt.as_ref().is_some_and(|receipt| receipt.record.checkpoint.is_some());
                    app.fabric_runtime.close(&id); run.terminal = None; run.completed_at = None;
                    run.status = if proved { AgentStatus::Paused } else { AgentStatus::Orphaned };
                    run.last_error = Some(if proved { "managed helper stopped with retained checkpoint; source acceptance remains pending".into() }
                        else { "managed helper exited without a matching shutdown receipt; recovery required".into() });
                    let _ = save_native_run_record(&app.cwd, run); self.live.remove(&id); app.dirty = true;
                } else if exit.is_err() {
                    live.uncertain = true;
                }
            }
            Ok(())
        }
    }

    fn orphan(repo: &Path, run: &mut AgentRun, reason: &str) {
        run.status = AgentStatus::Orphaned; run.completed_at = None; run.last_error = Some(reason.into());
        let _ = save_native_run_record(repo, run);
    }

    pub(crate) fn stop(app: &mut App, index: usize) -> Option<bool> {
        let run = app.agents.get_mut(index)?;
        run.managed_local.as_ref()?;
        if let Some(pending) = app.managed_local.pending.get(&run.id) {
            pending.cancelled.store(true, Ordering::Release);
            run.status = AgentStatus::Stopped; run.completed_at = None;
            run.last_error = Some("managed launch cancelled before helper adoption".into());
        } else if let Some(live) = app.managed_local.live.get_mut(&run.id) {
            if live.stop.is_none() && !live.uncertain {
                let assignment = &live.prepared.assignment; let fence = &assignment.fence;
                let request = StopAndCheckpoint { request_id: uuid::Uuid::new_v4().to_string(), execution_id: fence.attempt_id.clone(),
                    operation_id: assignment.observation.attempt.operation_id.clone(), view_id: assignment.observation.view_id.clone(),
                    run_id: fence.run_id.clone(), run_epoch: fence.run_epoch, owner: fence.owner_epoch() };
                let result = run.terminal.as_ref().context("managed terminal is absent").and_then(|terminal|
                    app.fabric_runtime.begin_managed_shutdown(&fence.owner, assignment, terminal))
                    .and_then(|_|live.control.stop_and_checkpoint(request.clone()));
                if result.is_ok() { live.stop = Some((request, Instant::now())); }
                else { live.uncertain = true; }
            }
            run.last_error = Some("stopping exact managed helper; awaiting checkpoint and physical exit".into());
        } else {
            orphan(&app.cwd, run, "managed source requires explicit owned recovery; no legacy stop/resume path");
        }
        let _ = save_native_run_record(&app.cwd, run); app.dirty = true;
        Some(true)
    }

    pub(crate) fn abandon(app: &mut App, run_id: &str) {
        if let Some(pending) = app.managed_local.pending.get(run_id) { pending.cancelled.store(true, Ordering::Release); }
        app.fabric_runtime.close(run_id);
        // Dropping the handle closes the private control channel. The helper
        // must withhold checkpoint authority and retains its orphan resources.
        app.managed_local.live.remove(run_id);
    }

    #[cfg(test)]
    mod tests {
        use super::*;
        #[test]
        fn cancelled_or_timed_out_workers_hold_admission_until_actual_settlement() {
            let queue = WorkerQueue::new();
            let (release, receive) = mpsc::sync_channel(1);
            let cancelled = Arc::new(AtomicBool::new(false));
            let observed = cancelled.clone();
            let first = queue.admit().unwrap();
            queue.spawn(first, None, move |_| { receive.recv().unwrap(); observed.load(Ordering::Acquire) }).unwrap();
            let second = queue.admit().unwrap();
            cancelled.store(true, Ordering::Release);
            assert!(queue.admit().is_err(), "cancellation cannot release an executing worker's permit");
            drop(second);
            let second = queue.admit().unwrap();
            assert!(queue.admit().is_err());
            release.send(()).unwrap();
            assert!(queue.receive.recv_timeout(Duration::from_secs(2)).unwrap());
            let deadline = Instant::now() + Duration::from_secs(2);
            while queue.active.load(Ordering::Acquire) == MAX_PREPARATIONS && Instant::now() < deadline { thread::yield_now(); }
            let recovered = queue.admit().unwrap();
            drop(recovered); drop(second);
            assert_eq!(queue.active.load(Ordering::Acquire), 0);
        }
        #[test]
        fn failed_worker_spawn_or_panic_releases_its_actual_admission() {
            let queue = WorkerQueue::<()>::new();
            let permit = queue.admit().unwrap();
            let thread = thread::spawn(move || { let _permit = permit; panic!("fixture worker failure"); });
            assert!(thread.join().is_err());
            assert_eq!(queue.active.load(Ordering::Acquire), 0);
        }
    }
}

#[cfg(target_os = "linux")]
pub(crate) use local::{ManagedAppState, poll, stop, abandon};

#[cfg(not(target_os = "linux"))]
#[derive(Default)]
pub(crate) struct ManagedAppState;
#[cfg(not(target_os = "linux"))]
pub(crate) fn poll(_: &mut App, _: &mut Journal, _: &OwnerFence) -> Result<()> { Ok(()) }
#[cfg(not(target_os = "linux"))]
pub(crate) fn stop(app: &mut App, index: usize) -> Option<bool> {
    let run = app.agents.get_mut(index)?;
    run.managed_local.as_ref()?;
    run.status = AgentStatus::Orphaned;
    run.last_error = Some("managed local execution requires a qualified Linux worker".into());
    Some(false)
}
#[cfg(not(target_os = "linux"))]
pub(crate) fn abandon(_: &mut App, _: &str) {}
#[cfg(not(target_os = "linux"))]
impl App {
    pub(crate) fn start_managed_local(&mut self, _: usize, _: ManagedLocalLaunchInputs, _: PathBuf,
        _: &mut Journal, _: &OwnerFence) -> Result<ManagedLaunchFence> {
        Err(io::Error::new(io::ErrorKind::Unsupported, "managed local execution requires a qualified Linux worker").into())
    }
}

#[cfg(test)]
#[path = "managed_app_tests.rs"]
mod integration_tests;
