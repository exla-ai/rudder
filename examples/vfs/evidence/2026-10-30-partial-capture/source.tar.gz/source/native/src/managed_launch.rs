//! Explicit local launch preparation. Every API doing IO runs off the App loop.
//! Persisted assignments contain no provider material; execution specs remain
//! private in memory and cross the one-use sealed descriptor handoff only.
use anyhow::{ensure, Context, Result};
use rudder_engine::{
    execution::{ExecutionSpec, ProtectedHostContextRef, HomeFile, ReadOnlyRuntime,
        BrokerBinding, WorkspaceObservationProfile, HelperApplicationSpec},
    journal::{Journal, OwnerFence},
    protocol::{canonical_json, ObjectKind, ObjectRef, OwnerEpoch},
    vfs::{rpc::{ObservationBinding, AttemptContext}, VfsManager, VfsCheckpoint},
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{fs::{self, File, OpenOptions}, io::{Read, Write},
    os::unix::fs::{DirBuilderExt, MetadataExt, OpenOptionsExt, PermissionsExt}, path::{Path, PathBuf},
    sync::{atomic::{AtomicBool, Ordering}, Arc, OnceLock, mpsc::{self, SyncSender}}};
use rudder_vcs_bridge::{seed::{VerifiedMetadataTemplate, fork_private_metadata},
    vfs_provider::SourceProjectionPolicy, command_transport::CommandServiceConfig,
    rpc_view::RpcViewConfig};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ManagedLaunchFence {
    pub owner: OwnerFence,
    pub run_id: String,
    pub run_epoch: u64,
    pub attempt_id: String,
    pub request_id: String,
}
impl ManagedLaunchFence {
    pub(crate) fn validate(&self) -> Result<()> {
        ensure!(!self.run_id.is_empty() && self.run_id.len() <= 256
            && !self.run_id.chars().any(char::is_control) && self.run_epoch > 0,
            "invalid reserved managed run");
        self.owner_epoch().validate()?;
        for id in [&self.attempt_id, &self.request_id] {
            ensure!(uuid::Uuid::parse_str(id).is_ok_and(|u| u.to_string() == *id),
                "managed launch identity must be an App-reserved canonical UUID");
        }
        Ok(())
    }
    pub(crate) fn owner_epoch(&self) -> OwnerEpoch {
        OwnerEpoch { owner: self.owner.owner_id.clone(), epoch: self.owner.epoch }
    }
    pub(crate) fn check_current(&self, journal: &Journal) -> Result<()> {
        self.validate()?;
        ensure!(journal.current_run_attempt(&self.owner, &self.run_id, self.run_epoch)? == self.attempt_id,
            "managed launch reservation is stale");
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct WorkspaceAssignment {
    pub format_version: u32,
    pub fence: ManagedLaunchFence,
    pub runnable_root: ObjectRef,
    pub source: ObjectRef,
    pub seed: ObjectRef,
    pub observation: ObservationBinding,
    pub host_context: ProtectedHostContextRef,
}
impl WorkspaceAssignment {
    pub(crate) fn validate(&self, fence: &ManagedLaunchFence) -> Result<()> {
        fence.validate()?;
        self.observation.validate()?;
        self.host_context.validate()?;
        for reference in [&self.runnable_root, &self.source, &self.seed] { reference.validate()?; }
        ensure!(self.format_version == 1 && self.fence == *fence
            && self.runnable_root.kind == ObjectKind::RunnableRoot
            && self.source.kind == ObjectKind::SourceRoot && self.seed.kind == ObjectKind::Directory
            && self.observation.attempt.execution_id == fence.attempt_id
            && self.observation.owner == fence.owner_epoch(),
            "workspace assignment differs from the exact reserved attempt");
        Ok(())
    }
}

/// Durable source identity only. Restored records are recovery evidence, never
/// a live owner grant or permission to reopen a checkout-backed conversation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "phase", rename_all = "snake_case", deny_unknown_fields)]
pub(crate) enum ManagedRunSource {
    Reserved { fence: ManagedLaunchFence, runnable_root: ObjectRef },
    Assigned { assignment: Box<WorkspaceAssignment> },
    /// A malformed persisted marker remains visibly managed and quarantined.
    /// It cannot be supplied as an alternate valid public launch format.
    #[serde(skip_deserializing)]
    Quarantined,
}
impl ManagedRunSource {
    pub(crate) fn validate(&self, run_id: &str) -> Result<()> {
        let fence = match self {
            Self::Reserved { fence, runnable_root } => {
                runnable_root.validate()?;
                ensure!(runnable_root.kind == ObjectKind::RunnableRoot, "managed reservation has no RunnableRoot");
                fence
            }
            Self::Assigned { assignment } => { assignment.validate(&assignment.fence)?; &assignment.fence }
            Self::Quarantined => anyhow::bail!("managed source marker requires explicit recovery"),
        };
        fence.validate()?;
        ensure!(fence.run_id == run_id, "managed source marker belongs to another run"); Ok(())
    }
    pub(crate) fn fence(&self) -> Option<&ManagedLaunchFence> {
        match self { Self::Reserved { fence, .. } => Some(fence), Self::Assigned { assignment } => Some(&assignment.fence), Self::Quarantined => None }
    }
}

pub(crate) fn assignment_path(home: &Path, fence: &ManagedLaunchFence) -> Result<PathBuf> {
    fence.validate()?;
    let digest = Sha256::digest(canonical_json(&(fence.owner.clone(), &fence.run_id, &fence.attempt_id))?);
    Ok(home.join("fabric/workspace-assignments").join(format!("{}.json", hex_digest(digest))))
}
fn hex_digest(bytes: impl AsRef<[u8]>) -> String { bytes.as_ref().iter().map(|b| format!("{b:02x}")).collect() }

/// Off-App. Persist BEFORE granting workspace access. An existing assignment
/// can only reconcile the identical request; it cannot widen a running token.
pub(crate) fn persist_assignment(home: &Path, assignment: &WorkspaceAssignment) -> Result<()> {
    assignment.validate(&assignment.fence)?;
    let path = assignment_path(home, &assignment.fence)?;
    let parent = path.parent().unwrap();
    fs::DirBuilder::new().recursive(true).mode(0o700).create(parent)?;
    let meta = fs::symlink_metadata(parent)?;
    ensure!(meta.is_dir() && meta.uid() == unsafe { libc::geteuid() } && meta.mode() & 0o077 == 0,
        "workspace assignment directory is not private");
    let bytes = canonical_json(assignment)?;
    if path.try_exists()? {
        ensure!(read_assignment(home, &assignment.fence)? == Some(assignment.clone()),
            "workspace assignment already belongs to different launch inputs");
        return Ok(());
    }
    let mut file = OpenOptions::new().write(true).create_new(true).mode(0o600)
        .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC).open(&path)?;
    file.write_all(&bytes)?; file.sync_all()?; File::open(parent)?.sync_all()?;
    Ok(())
}
/// Off-App. Missing means legacy. Invalid/stale data fails closed.
pub(crate) fn read_assignment(home: &Path, fence: &ManagedLaunchFence) -> Result<Option<WorkspaceAssignment>> {
    read_assignment_record(home, fence, true)
}
pub(crate) fn assignment_for_attempt(home: &Path, owner: &OwnerFence, run_id: &str, run_epoch: u64, attempt: &str) -> Result<Option<WorkspaceAssignment>> {
    let key = ManagedLaunchFence { owner: owner.clone(), run_id: run_id.into(), run_epoch,
        attempt_id: attempt.into(), request_id: attempt.into() };
    read_assignment_record(home, &key, false)
}
fn read_assignment_record(home: &Path, fence: &ManagedLaunchFence, exact_request: bool) -> Result<Option<WorkspaceAssignment>> {
    let path = assignment_path(home, fence)?;
    let file = match OpenOptions::new().read(true).custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC).open(path) {
        Ok(file) => file,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(error.into()),
    };
    let meta = file.metadata()?;
    ensure!(meta.is_file() && meta.uid() == unsafe { libc::geteuid() } && meta.nlink() == 1
        && meta.mode() & 0o077 == 0 && meta.len() <= 64 * 1024, "unsafe workspace assignment");
    let mut bytes = Vec::new(); file.take(64 * 1024 + 1).read_to_end(&mut bytes)?;
    let assignment: WorkspaceAssignment = serde_json::from_slice(&bytes)?;
    assignment.validate(&assignment.fence)?;
    ensure!(assignment.fence.owner == fence.owner && assignment.fence.run_id == fence.run_id
        && assignment.fence.run_epoch == fence.run_epoch && assignment.fence.attempt_id == fence.attempt_id
        && (!exact_request || assignment.fence == *fence), "workspace assignment is stale");
    ensure!(canonical_json(&assignment)? == bytes, "noncanonical workspace assignment");
    Ok(Some(assignment))
}

/// No Debug/Serialize implementation: values belong only in a sealed spec.
pub(crate) struct SelectedCredentials {
    profile_id: String,
    backend: super::Backend,
    environment: std::collections::BTreeMap<String, String>,
}
impl SelectedCredentials {
    /// The selected profile loader supplies exactly one key, never its HOME or
    /// inherited environment. API keys have no refresh/writeback semantics.
    pub(crate) fn api_key(profile_id: String, backend: super::Backend, secret: String) -> Result<Self> {
        ensure!(!profile_id.is_empty() && profile_id.len() <= 256 && !profile_id.chars().any(char::is_control), "invalid selected credential profile");
        ensure!(!secret.is_empty() && secret.len() <= 16 * 1024 && !secret.contains(['\0', '\r', '\n']), "invalid selected provider credential");
        let key = match backend {
            super::Backend::Codex => "OPENAI_API_KEY",
            super::Backend::Claude => "ANTHROPIC_API_KEY",
            _ => anyhow::bail!("managed provider profile is unsupported"),
        };
        Ok(Self { profile_id, backend, environment: [(key.into(), secret)].into() })
    }
    /// Ordinary CLI profiles do not participate in a shared refresh lease.
    /// Refuse before reading/copying a refresh token or invalidating a live login.
    pub(crate) fn oauth_profile(_profile_id: &str) -> Result<Self> {
        Err(std::io::Error::new(std::io::ErrorKind::Unsupported,
            "managed OAuth requires a qualified exclusive refresh and protected writeback adapter").into())
    }
}
impl Drop for SelectedCredentials {
    fn drop(&mut self) {
        for value in self.environment.values_mut() { unsafe { value.as_bytes_mut().fill(0); } }
    }
}

/// Explicit backend process layout. Both commands contain guest paths only.
/// The helper launches the server directly and reports its held kernel identity.
pub(crate) enum ManagedBackendProfile {
    CodexAppServer { program: String, arguments: Vec<String> },
    ClaudeSdk { node: String, rudder_cli: String, claude: String,
        arguments: Vec<String>, initial_prompt: Option<String> },
}
impl ManagedBackendProfile {
    pub(crate) fn backend(&self) -> super::Backend {
        match self { Self::CodexAppServer { .. } => super::Backend::Codex,
            Self::ClaudeSdk { .. } => super::Backend::Claude }
    }
    pub(crate) fn execution_profile(&self) -> &'static str {
        match self { Self::CodexAppServer { .. } => "codex-app-server",
            Self::ClaudeSdk { .. } => "claude-sdk" }
    }
}

pub(crate) struct ManagedLocalLaunchRequest {
    pub fence: ManagedLaunchFence,
    pub journal: PathBuf,
    pub home: PathBuf,
    pub store: rudder_engine::store::LocalStore,
    pub runnable_root: ObjectRef,
    /// Trusted accepted-history binding. Never inferred from a checkout/cwd.
    pub seed_source: ObjectRef,
    pub seed: VerifiedMetadataTemplate,
    pub operation_id: String,
    pub view_id: String,
    /// New owned directory, ending in the reserved request UUID.
    pub private_root: PathBuf,
    pub backend: ManagedBackendProfile,
    pub credentials: SelectedCredentials,
    pub runtime: Vec<ReadOnlyRuntime>,
    pub native_guest: String,
    pub jj_guest: String,
    pub user_name: String,
    pub user_email: String,
    pub timeout_seconds: u64,
}

/// An explicit retained-root launch selection, without any run UUIDs. The App
/// reserves all identities before moving this value to the bounded IO worker.
/// Construct/verify retained seed/runtime/credential values off-App; this type
/// performs no profile lookup, environment scan or checkout inference.
pub(crate) struct ManagedLocalLaunchInputs {
    pub journal: PathBuf,
    pub home: PathBuf,
    pub store: rudder_engine::store::LocalStore,
    pub runnable_root: ObjectRef,
    pub seed_source: ObjectRef,
    pub seed: VerifiedMetadataTemplate,
    pub preparation_parent: PathBuf,
    pub backend: ManagedBackendProfile,
    pub credentials: SelectedCredentials,
    pub runtime: Vec<ReadOnlyRuntime>,
    pub native_guest: String,
    pub jj_guest: String,
    pub user_name: String,
    pub user_email: String,
    pub timeout_seconds: u64,
}
impl ManagedLocalLaunchInputs {
    pub(crate) fn bind(self, fence: ManagedLaunchFence, operation_id: String, view_id: String) -> ManagedLocalLaunchRequest {
        ManagedLocalLaunchRequest { private_root: self.preparation_parent.join(&fence.request_id), fence,
            journal: self.journal, home: self.home, store: self.store, runnable_root: self.runnable_root,
            seed_source: self.seed_source, seed: self.seed, operation_id, view_id, backend: self.backend,
            credentials: self.credentials, runtime: self.runtime, native_guest: self.native_guest,
            jj_guest: self.jj_guest, user_name: self.user_name, user_email: self.user_email, timeout_seconds: self.timeout_seconds }
    }
}

/// Credential-free, explicit path mapping. A pathname is never readiness.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ManagedTransportMapping {
    pub host_socket: PathBuf,
    pub guest_socket: PathBuf,
    pub guest_cwd: PathBuf,
}

/// Guest-owned candidate reports. These paths convey no backend/process,
/// acknowledgment, writer-barrier or checkpoint authority.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct ManagedReportMapping {
    pub host_done_file: PathBuf,
    pub guest_done_file: PathBuf,
    pub host_signal_file: PathBuf,
    pub guest_signal_file: PathBuf,
}
impl ManagedReportMapping {
    fn for_execution(home: &Path) -> Self {
        Self { host_done_file: home.join(".rudder-reports/done.json"),
            guest_done_file: "/home/agent/.rudder-reports/done.json".into(),
            host_signal_file: home.join(".rudder-reports/signal.json"),
            guest_signal_file: "/home/agent/.rudder-reports/signal.json".into() }
    }
}

pub(crate) struct PreparedManagedLaunch {
    pub assignment: WorkspaceAssignment,
    pub transport: ManagedTransportMapping,
    pub reports: ManagedReportMapping,
    pub execution_profile: String,
    pub identity_home: PathBuf,
    pub identity_journal: PathBuf,
    pub server_command: Option<Vec<String>>,
    spec: Option<ExecutionSpec>,
    retirement: Option<Retirement>,
}
impl PreparedManagedLaunch {
    #[cfg(target_os = "linux")]
    pub(crate) fn prepare_handoff(&self) -> Result<rudder_engine::execution::handoff::ManagedExecutionHandoff> {
        let spec = self.execution_spec()?;
        rudder_engine::execution::handoff::ManagedExecutionHandoff::new(spec,
            rudder_engine::execution::ManagedExecutionBinding { format_version: 1,
                request_id: self.assignment.fence.request_id.clone(), run_id: self.assignment.fence.run_id.clone(),
                run_epoch: self.assignment.fence.run_epoch, execution_id: spec.execution_id.clone(),
                operation_id: spec.operation_id.clone(), view_id: spec.view_id.clone(), owner: spec.owner.clone(),
                execution_profile: self.execution_profile.clone(), server_command: self.server_command.clone(),
                guest_socket: self.transport.guest_socket.clone() })
    }
    pub(crate) fn link_launch(&self) -> crate::agent_link::AgentLinkLaunch {
        crate::agent_link::AgentLinkLaunch { format_version: 1, run_id: self.assignment.fence.run_id.clone(),
            attempt_id: self.assignment.fence.attempt_id.clone(), backend: if self.execution_profile == "codex-app-server" { "codex".into() } else { self.execution_profile.clone() },
            socket_path: self.transport.host_socket.clone(), log_path: self.transport.host_socket.with_file_name("backend.log") }
    }
    /// Explicit unused-result retirement on a background worker. Adopted or
    /// uncertain running attempts retain their recovery state conservatively.
    pub(crate) fn retire(mut self) -> Result<()> {
        if let Some(retirement) = self.retirement.take() {
            ensure!(!retirement.adopted, "adopted managed execution requires receipt reconciliation");
            retire_unused(retirement)?;
        }
        Ok(())
    }
    /// Off-App. Called only after adopting this result and persisting its exact
    /// assignment. Capability projection must precede sealed-spec validation.
    pub(crate) fn execution_spec(&self) -> Result<&ExecutionSpec> {
        self.spec.as_ref().context("managed launch already consumed")
    }
    /// App adoption moves ownership without IO. Caller keeps this object until
    /// the matched helper record confirms termination; Drop does not retire a
    /// live adopted view or revoke authority needed for final checkpoint.
    pub(crate) fn adopt(&mut self) {
        if let Some(retirement) = &mut self.retirement { retirement.adopted = true; }
    }
}
struct Retirement {
    root: PathBuf,
    marker: Vec<u8>,
    store: rudder_engine::store::LocalStore,
    pins: Vec<String>,
    adopted: bool,
}
fn retire_unused(retirement: Retirement) -> Result<()> {
    if retirement.adopted { return Ok(()); }
    ensure!(fs::read(retirement.root.join("preparation.json"))? == retirement.marker,
        "managed preparation retirement identity changed");
    // Each pin includes this request UUID; shared preparation/cache pins are
    // deliberately retained. Never delete a manager owned by another attempt.
    for pin in &retirement.pins { retirement.store.unpin(pin)?; }
    fs::remove_dir_all(&retirement.root)?;
    Ok(())
}
fn retirement_queue() -> Option<&'static SyncSender<Retirement>> {
    static QUEUE: OnceLock<Option<SyncSender<Retirement>>> = OnceLock::new();
    QUEUE.get_or_init(|| {
        let (send, receive) = mpsc::sync_channel::<Retirement>(32);
        std::thread::Builder::new().name("rudder-managed-retirement".into()).spawn(move || {
            while let Ok(retirement) = receive.recv() { let _ = retire_unused(retirement); }
        }).ok().map(|_| send)
    }).as_ref()
}
impl Drop for PreparedManagedLaunch {
    fn drop(&mut self) {
        // No filesystem, database or child waits on the App thread. On bounded
        // queue exhaustion the durable preparation marker and pins remain for
        // explicit reconciliation; no success/retirement is inferred.
        if let Some(retirement) = self.retirement.take().filter(|r| !r.adopted) {
            if let Some(queue) = retirement_queue() { let _ = queue.try_send(retirement); }
        }
        if let Some(spec) = &mut self.spec {
            for value in spec.environment.values_mut() { unsafe { value.as_bytes_mut().fill(0); } }
            for file in &mut spec.home_files { file.contents.fill(0); }
        }
    }
}

/// Blocking IO only. No App access, PTY spawn, capability grant, run observation
/// or provider call. Every identity was reserved by the App before invocation.
pub(crate) fn prepare_local(request: ManagedLocalLaunchRequest, cancelled: Arc<AtomicBool>) -> Result<PreparedManagedLaunch> {
    ensure!(cfg!(target_os = "linux"), "managed local execution requires a qualified Linux worker");
    let journal = Journal::open(&request.journal)?;
    let check = || -> Result<()> {
        ensure!(!cancelled.load(Ordering::Acquire), "managed launch preparation cancelled");
        request.fence.check_current(&journal)
    };
    check()?;
    for id in [&request.operation_id, &request.view_id] {
        ensure!(uuid::Uuid::parse_str(id).is_ok_and(|u| u.to_string() == *id), "managed workspace UUID was not explicitly reserved");
    }
    ensure!(request.private_root.is_absolute() && request.private_root.components()
        .all(|component| matches!(component, std::path::Component::RootDir | std::path::Component::Normal(_)))
        && request.private_root.file_name()
        .is_some_and(|n| n == request.fence.request_id.as_str()), "managed private root must bind its reserved request");
    ensure!((1..=24 * 60 * 60).contains(&request.timeout_seconds), "invalid managed execution timeout");
    ensure!(request.backend.backend() == request.credentials.backend,
        "selected credential profile belongs to another backend");
    ensure!(request.runnable_root.kind == ObjectKind::RunnableRoot, "managed local launch requires a RunnableRoot");
    let seed_ref = request.seed.retained_seed().context("managed local launch requires a retained private seed")?.clone();
    let retained = request.store.retention()?;
    for root in [&request.runnable_root, &seed_ref] {
        ensure!(retained.pins.values().any(|r| r == root), "managed launch input has no retained LOCAL authority");
    }
    let runnable = rudder_engine::snapshot::decode_runnable(&request.store.read_object(&request.runnable_root)?)?;
    ensure!(request.seed_source == runnable.source, "private VCS seed belongs to another accepted source");
    let source = rudder_engine::snapshot::decode_source(&request.store.read_object(&runnable.source)?)?;
    let profile: rudder_engine::workspace::WorkspaceProfile = serde_json::from_slice(&request.store.read_object(&runnable.profile)?)?;
    let policy = SourceProjectionPolicy::from_import_policy(&profile.source_exclusions())?;
    ensure!(request.store.read_object(&source.projection_policy)? == canonical_json(&policy)?,
        "managed source policy differs from its selected workspace profile");
    check()?;
    fs::DirBuilder::new().mode(0o700).create(&request.private_root)?;
    let marker = canonical_json(&serde_json::json!({"format_version":1,"fence":request.fence,
        "runnable_root":request.runnable_root,"seed":seed_ref,"phase":"preparing"}))?;
    let mut file = OpenOptions::new().create_new(true).write(true).mode(0o600)
        .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC).open(request.private_root.join("preparation.json"))?;
    file.write_all(&marker)?; file.sync_all()?; File::open(&request.private_root)?.sync_all()?;
    let mut retirement = Retirement { root: request.private_root.clone(), marker,
        store: request.store.clone(), pins: Vec::new(), adopted: false };
    let prepared = (|| -> Result<PreparedManagedLaunch> {
        for (kind, root) in [("runnable", &request.runnable_root), ("seed", &seed_ref)] {
            let pin = format!("managed:{}:{kind}", request.fence.request_id);
            request.store.pin_existing(&pin, root)?; retirement.pins.push(pin);
        }
        let manager = VfsManager::open(request.private_root.join("vfs"), request.store.clone())?;
        let snapshot = VfsCheckpoint { format_version: 1, directory: runnable.view_root.clone(), hardlinks: runnable.hardlinks.clone() };
        manager.prepare_paged_snapshot(&snapshot)?;
        let view = manager.fork_paged_snapshot(&request.view_id, &snapshot, request.fence.owner_epoch())?;
        retirement.pins.extend([format!("vfs:view:{}:base", request.view_id), format!("vfs:view:{}:topology", request.view_id)]);
        check()?;
        let observation = ObservationBinding { format_version: 1,
            attempt: AttemptContext { execution_id: request.fence.attempt_id.clone(), operation_id: request.operation_id.clone() },
            view_id: request.view_id.clone(), owner: request.fence.owner_epoch(), namespace: view.dirty_cursor()?.namespace,
            profile: runnable.profile.clone(), exclusion_policy_digest: rudder_engine::vfs::exclusion_policy_digest(&profile.source_exclusions())? };
        let binding = rudder_vcs_bridge::AttemptBinding { format_version: 1, project_id: request.fence.owner.project_id.clone(),
            owner: request.fence.owner_epoch(), run_id: request.fence.run_id.clone(), run_epoch: request.fence.run_epoch,
            attempt_id: request.fence.attempt_id.clone(), view_id: request.view_id.clone(), seed: seed_ref.clone(),
            baseline: request.seed.manifest().baseline.clone(), baseline_operation: request.seed.manifest().operation.clone(),
            projection_policy: policy.reference()?, profile: runnable.profile.clone() };
        let private = request.private_root.join("private");
        // A local seed with LocalWC metadata is rebound by the post-RPC host
        // factory. Already-bound Rudder metadata needs a fresh observation and
        // is explicitly refused here rather than inventing one before RPC.
        fork_private_metadata(&request.seed, &private, binding.clone(), None)?;
        check()?;
        for name in ["context", "state", "projections", "endpoints"] {
            fs::DirBuilder::new().mode(0o700).create(request.private_root.join(name))?;
        }
        let endpoint = request.private_root.join("workspace");
        let service = CommandServiceConfig { format_version: 1,
            view: RpcViewConfig { format_version: 1, attempt: binding, observation: observation.clone(),
                socket: endpoint.join("workspace.sock"), identity_file: endpoint.join("identity.json"),
                private_repository: private.clone(), private_git: private.join(".git"),
                projection_state: request.private_root.join("projections"), cas_root: request.store.root().into(),
                policy, budget: Default::default() }, binary: PathBuf::new(), state_directory: request.private_root.join("state"),
            git_config_sha256: hex_digest(Sha256::digest(fs::read(private.join(".git/config"))?)),
            user_name: request.user_name.clone(), user_email: request.user_email.clone(), command_timeout_ms: 20_000 };
        let context = crate::workspace_vcs::context_with_companion(service, request.jj_guest.clone())?;
        let host_context = crate::workspace_vcs::write_host_context(&request.private_root.join("context/launch.json"), &context)?;
        let assignment = WorkspaceAssignment { format_version: 1, fence: request.fence.clone(),
            runnable_root: request.runnable_root.clone(), source: runnable.source.clone(), seed: seed_ref.clone(),
            observation: observation.clone(), host_context: host_context.clone() };
        assignment.validate(&request.fence)?;
        let execution_root = request.private_root.join("e");
        let host_socket = execution_root.join("runs").join(&request.fence.attempt_id).join("tmp/cx.sock");
        ensure!(host_socket.as_os_str().as_encoded_bytes().len() < 100, "managed backend socket exceeds portable path bound");
        let guest_socket = PathBuf::from("/tmp/cx.sock");
        let (command, server_command, home_files) = prepare_backend(&request.fence, &request.backend, &request.native_guest, &guest_socket)?;
        let reports = ManagedReportMapping::for_execution(&execution_root.join("runs").join(&request.fence.attempt_id).join("home"));
        let broker = crate::agent_broker::socket_path(&request.home, &request.fence.owner.project_id,
            &request.fence.run_id, &request.fence.attempt_id);
        let mut environment = request.credentials.environment.clone();
        environment.extend([("RUDDER_FABRIC_ATTEMPT_ID".into(), request.fence.attempt_id.clone()),
            ("RUDDER_DONE_FILE".into(), reports.guest_done_file.display().to_string()),
            ("CODEX_HOME".into(), "/home/agent/.codex".into())]);
        let spec = ExecutionSpec { format_version: 3, execution_id: request.fence.attempt_id.clone(),
            operation_id: request.operation_id.clone(), execution_root, manager_root: manager.root().into(),
            store_root: request.store.root().into(), authority_roots: vec![private, request.private_root.join("context"),
                request.private_root.join("state"), request.private_root.join("projections"), request.journal.clone()],
            view_id: request.view_id.clone(), owner: request.fence.owner_epoch(), command, environment,
            runtime: request.runtime.clone(), home_files, broker_directory: Some(broker.parent().unwrap().into()),
            broker_binding: Some(BrokerBinding { project_id: request.fence.owner.project_id.clone(),
                run_id: request.fence.run_id.clone(), run_epoch: request.fence.run_epoch, owner_epoch: request.fence.owner.epoch }),
            workspace_observation: Some(WorkspaceObservationProfile { binding: observation, endpoint_directory: endpoint,
                application: Some(HelperApplicationSpec { format_version: 1, kind: crate::workspace_vcs::KIND.into(),
                    host_context, projection_directory: request.private_root.join("endpoints/vcs") }) }), timeout_seconds: request.timeout_seconds };
        spec.validate()?;
        check()?;
        File::open(&request.private_root)?.sync_all()?;
        File::open(request.private_root.parent().context("managed root parent absent")?)?.sync_all()?;
        Ok(PreparedManagedLaunch { assignment, transport: ManagedTransportMapping { host_socket, guest_socket, guest_cwd: "/workspace".into() }, reports,
            execution_profile: request.backend.execution_profile().into(), identity_home: request.home.clone(),
            identity_journal: request.journal.clone(), server_command, spec: Some(spec), retirement: None })
    })();
    match prepared {
        Ok(mut prepared) => { prepared.retirement = Some(retirement); Ok(prepared) }
        Err(error) => { let _ = retire_unused(retirement); Err(error) }
    }
}

fn prepare_backend(fence: &ManagedLaunchFence, backend: &ManagedBackendProfile, native_guest: &str,
    socket: &Path) -> Result<(Vec<String>, Option<Vec<String>>, Vec<HomeFile>)> {
    let broker_args = vec!["fabric", "mcp", "--identity-file", "/run/rudder/agent/identity.json", "--broker-socket", "/run/rudder/agent/broker.sock"];
    let config = canonical_json(&serde_json::json!({"mcpServers":{"rudder_agents":{"type":"stdio",
        "command":native_guest,"args":broker_args}}}))?;
    let signal = Path::new("/home/agent/.rudder-reports/signal.json");
    let mut files = vec![HomeFile { relative_path: ".rudder/mcp.json".into(), contents: config },
        HomeFile { relative_path: ".rudder-reports/assignment.json".into(), contents: canonical_json(fence)? }];
    let mut codex_configs = vec!["-c".into(), format!("mcp_servers.rudder_agents.command={}", serde_json::to_string(native_guest)?),
        "-c".into(), format!("mcp_servers.rudder_agents.args={}", serde_json::to_string(&broker_args)?),
        "-c".into(), "mcp_servers.rudder_agents.enabled=true".into(),
        "-c".into(), "notify=[\"/bin/sh\",\"/home/agent/.rudder/notify.sh\"]".into()];
    match backend {
        ManagedBackendProfile::CodexAppServer { program, arguments } => {
            ensure!(Path::new(program).is_absolute() && !arguments.iter().any(|a| matches!(a.as_str(), "exec" | "app-server" | "--remote") || a.starts_with("--remote=")), "invalid explicit Codex interactive profile");
            files.push(HomeFile { relative_path: ".rudder/notify.sh".into(), contents: crate::signals::codex_notify_script(signal).into_bytes() });
            let mut server = vec![program.clone()];
            // The server owns MCP and lifecycle configuration. Preserve explicit
            // root options before applying this attempt's guest-only overrides.
            let mut at = 0;
            while at < arguments.len() {
                let arg = &arguments[at];
                if matches!(arg.as_str(), "-c" | "--config" | "--enable" | "--disable" | "--profile" | "-p") {
                    let value = arguments.get(at + 1).context("Codex root option is missing its value")?;
                    server.extend([arg.clone(), value.clone()]); at += 2;
                } else if ["--config=", "--enable=", "--disable=", "--profile="].iter().any(|prefix| arg.starts_with(prefix)) {
                    server.push(arg.clone()); at += 1;
                } else { at += 1; }
            }
            server.append(&mut codex_configs);
            server.extend(["app-server".into(), "--listen".into(), format!("unix://{}", socket.display())]);
            let mut terminal = vec![program.clone(), "--remote".into(), format!("unix://{}", socket.display())];
            terminal.extend(arguments.clone()); Ok((terminal, Some(server), files))
        }
        ManagedBackendProfile::ClaudeSdk { node, rudder_cli, claude, arguments, initial_prompt } => {
            for path in [node, rudder_cli, claude] { ensure!(Path::new(path).is_absolute(), "managed Claude programs must use explicit guest paths"); }
            files.push(HomeFile { relative_path: ".rudder/claude-settings.json".into(), contents: crate::signals::claude_settings_json(signal, false).into_bytes() });
            let mut arguments = arguments.clone(); arguments.extend(["--mcp-config".into(), "/home/agent/.rudder/mcp.json".into(),
                "--settings".into(), "/home/agent/.rudder/claude-settings.json".into()]);
            files.push(HomeFile { relative_path: ".rudder/claude-launch.json".into(), contents: canonical_json(&serde_json::json!({
                "format_version":1,"run_id":fence.run_id,"attempt_id":fence.attempt_id,"socket_path":socket,
                "claude_program":claude,"claude_args":arguments,"initial_prompt":initial_prompt}))? });
            Ok((vec![node.clone(), rudder_cli.clone(), "__claude-sdk".into(), "--launch-file".into(), "/home/agent/.rudder/claude-launch.json".into()], None, files))
        }
    }
}

#[cfg(test)]
#[path = "managed_launch_tests.rs"]
mod tests;
