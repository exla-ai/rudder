use super::*;
use rudder_engine::protocol::ObjectKind;

struct Fixture(PathBuf);
impl Fixture {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!("rudder-managed-{}", uuid::Uuid::new_v4()));
        fs::create_dir(&path).unwrap();
        fs::set_permissions(&path, fs::Permissions::from_mode(0o700)).unwrap();
        Self(path)
    }
}
impl Drop for Fixture { fn drop(&mut self) { let _ = fs::remove_dir_all(&self.0); } }
fn fence() -> ManagedLaunchFence {
    ManagedLaunchFence { owner: OwnerFence { project_id: "project".into(), owner_id: "owner".into(), epoch: 1 },
        run_id: "run".into(), run_epoch: 1, attempt_id: uuid::Uuid::new_v4().to_string(), request_id: uuid::Uuid::new_v4().to_string() }
}
fn assignment(fence: &ManagedLaunchFence) -> WorkspaceAssignment {
    let reference = |kind, bytes: &[u8]| ObjectRef::from_bytes(kind, bytes);
    WorkspaceAssignment { format_version: 1, fence: fence.clone(),
        runnable_root: reference(ObjectKind::RunnableRoot, b"runnable"),
        source: reference(ObjectKind::SourceRoot, b"source"), seed: reference(ObjectKind::Directory, b"seed"),
        observation: ObservationBinding { format_version: 1,
            attempt: AttemptContext { execution_id: fence.attempt_id.clone(), operation_id: uuid::Uuid::new_v4().to_string() },
            view_id: uuid::Uuid::new_v4().to_string(), owner: fence.owner_epoch(), namespace: uuid::Uuid::new_v4().to_string(),
            profile: reference(ObjectKind::Blob, b"profile"), exclusion_policy_digest: "a".repeat(64) },
        host_context: ProtectedHostContextRef { format_version: 1, path: "/private/launch.json".into(),
            sha256: "b".repeat(64), size_bytes: 1 } }
}

#[test]
fn assignment_reconciles_exact_request_without_widening_or_reminting_identity() {
    let fixture = Fixture::new(); let fence = fence(); let assignment = assignment(&fence);
    persist_assignment(&fixture.0, &assignment).unwrap();
    persist_assignment(&fixture.0, &assignment).unwrap();
    assert_eq!(read_assignment(&fixture.0, &fence).unwrap(), Some(assignment.clone()));
    assert_eq!(assignment_for_attempt(&fixture.0, &fence.owner, &fence.run_id, fence.run_epoch, &fence.attempt_id).unwrap(), Some(assignment.clone()));
    let mut changed = assignment.clone(); changed.observation.namespace = uuid::Uuid::new_v4().to_string();
    assert!(persist_assignment(&fixture.0, &changed).is_err());
    let mut other = fence.clone(); other.request_id = uuid::Uuid::new_v4().to_string();
    assert!(read_assignment(&fixture.0, &other).is_err());
    other = fence.clone(); other.run_epoch += 1;
    assert!(read_assignment(&fixture.0, &other).is_err());
    other = fence.clone(); other.attempt_id = uuid::Uuid::new_v4().to_string();
    assert!(read_assignment(&fixture.0, &other).unwrap().is_none());
}

#[test]
fn assignment_cannot_rebind_owner_execution_or_object_kinds() {
    let fence = fence(); let value = assignment(&fence);
    let mut changed = value.clone(); changed.observation.owner.epoch += 1;
    assert!(changed.validate(&fence).is_err());
    changed = value.clone(); changed.observation.attempt.execution_id = uuid::Uuid::new_v4().to_string();
    assert!(changed.validate(&fence).is_err());
    changed = value; changed.runnable_root.kind = ObjectKind::Checkpoint;
    assert!(changed.validate(&fence).is_err());
}

#[test]
fn durable_managed_source_markers_remain_recovery_evidence_and_invalid_presence_is_quarantined() {
    let fixture = Fixture::new(); let fence = fence();
    let reserved = ManagedRunSource::Reserved { fence: fence.clone(), runnable_root: ObjectRef::from_bytes(ObjectKind::RunnableRoot, b"owned") };
    let assigned = ManagedRunSource::Assigned { assignment: Box::new(assignment(&fence)) };
    for source in [reserved, assigned] {
        let marker = serde_json::to_value(&source).unwrap();
        let record = serde_json::json!({"id":"run","task":"owned task","mode":"execute","status":"done", "managedLocal":marker,
            "session":{"nativeSessionId":"saved-session-is-not-liveness"}});
        let run = crate::gitio::agent_from_run_record(&fixture.0, record).unwrap();
        assert_eq!(run.managed_local, Some(source));
        assert_eq!(run.status, super::super::AgentStatus::Orphaned);
        assert!(!crate::launch::can_resume_agent(&run));
        crate::gitio::save_native_run_record(&fixture.0, &run).unwrap();
        let bytes = fs::read(crate::gitio::native_run_dir(&fixture.0, "run").join("run.json")).unwrap();
        let saved: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert!(saved.get("managedLocal").is_some());
        assert_eq!(saved["vcs"], "fabric");
        assert!(crate::gitio::agent_from_run_record(&fixture.0, saved).unwrap().managed_local.is_some());
    }
    let mut invalid = serde_json::to_value(ManagedRunSource::Reserved { fence, runnable_root: ObjectRef::from_bytes(ObjectKind::RunnableRoot, b"owned") }).unwrap();
    invalid["unknown_authority"] = serde_json::json!(true);
    for marker in [serde_json::Value::Null, serde_json::json!({}), invalid] {
        let record = serde_json::json!({"id":"run","task":"owned task","status":"running", "managedLocal":marker});
        let run = crate::gitio::agent_from_run_record(&fixture.0, record).unwrap();
        assert_eq!(run.managed_local, Some(ManagedRunSource::Quarantined));
        assert_eq!(run.status, super::super::AgentStatus::Orphaned);
        assert!(!crate::launch::can_resume_agent(&run));
    }
    let legacy = crate::gitio::agent_from_run_record(&fixture.0, serde_json::json!({"id":"legacy","task":"old task"})).unwrap();
    assert!(legacy.managed_local.is_none());
}

#[test]
fn assignment_files_refuse_symlinks_and_shared_modes() {
    let fixture = Fixture::new(); let fence = fence(); let assignment = assignment(&fence);
    persist_assignment(&fixture.0, &assignment).unwrap();
    let path = assignment_path(&fixture.0, &fence).unwrap();
    fs::set_permissions(&path, fs::Permissions::from_mode(0o644)).unwrap();
    assert!(read_assignment(&fixture.0, &fence).is_err());
    fs::remove_file(&path).unwrap();
    std::os::unix::fs::symlink("missing", path).unwrap();
    assert!(read_assignment(&fixture.0, &fence).is_err());
}

#[test]
fn current_launch_fence_requires_the_already_reserved_instance() {
    let fixture = Fixture::new(); let mut journal = Journal::open(fixture.0.join("journal.sqlite")).unwrap();
    let owner = journal.create_project("project", "owner", "base", 0).unwrap();
    let mut fence = fence(); fence.owner = owner;
    assert!(fence.check_current(&journal).is_err());
    fence.run_epoch = journal.observe_run_attempt(&fence.owner, &fence.run_id, &fence.attempt_id, 1).unwrap();
    fence.check_current(&journal).unwrap();
    journal.observe_run_attempt(&fence.owner, &fence.run_id, &uuid::Uuid::new_v4().to_string(), 2).unwrap();
    assert!(fence.check_current(&journal).is_err());
}

#[test]
fn selected_credentials_do_not_copy_environment_or_guess_an_oauth_profile() {
    let selected = SelectedCredentials::api_key("selected".into(), super::super::Backend::Codex, "fixture-secret".into()).unwrap();
    assert_eq!(selected.profile_id, "selected");
    assert_eq!(selected.environment.keys().map(String::as_str).collect::<Vec<_>>(), ["OPENAI_API_KEY"]);
    let error = match SelectedCredentials::oauth_profile("selected-oauth") { Ok(_) => panic!("unqualified refresh must refuse"), Err(error) => error };
    assert_eq!(error.downcast_ref::<std::io::Error>().unwrap().kind(), std::io::ErrorKind::Unsupported);
}

#[test]
fn managed_completion_paths_point_only_to_this_execution_home_and_remain_candidate_data() {
    let home = Path::new("/owned/request/e/runs/reserved-execution/home");
    let mapping = ManagedReportMapping::for_execution(home);
    assert_eq!(mapping.host_done_file, home.join(".rudder-reports/done.json"));
    assert_eq!(mapping.host_signal_file, home.join(".rudder-reports/signal.json"));
    assert_eq!(mapping.guest_done_file, Path::new("/home/agent/.rudder-reports/done.json"));
    let claude = crate::signals::claude_settings_json(&mapping.guest_signal_file, false);
    let codex = crate::signals::codex_notify_script(&mapping.guest_signal_file);
    for wiring in [&claude, &codex] {
        assert!(wiring.contains("/home/agent/.rudder-reports/signal.json"));
        assert!(!wiring.contains("/owned/") && !wiring.contains("fabric/agent-brokers"));
    }
}

#[test]
fn backend_mapping_keeps_mcp_hooks_and_sdk_config_in_the_owned_guest_home() {
    let fence = fence();
    let codex = ManagedBackendProfile::CodexAppServer { program: "/opt/runtime/codex".into(),
        arguments: vec!["--config".into(), "model_reasoning_effort=\"low\"".into(),
            "--config=notify=[\"/legacy/host-hook\"]".into(), "--model".into(), "chosen-model".into(), "hello".into()] };
    let (terminal, server, files) = prepare_backend(&fence, &codex, "/opt/rudder/native", Path::new("/tmp/cx.sock")).unwrap();
    assert_eq!(&terminal[..3], ["/opt/runtime/codex", "--remote", "unix:///tmp/cx.sock"]);
    let server = server.unwrap();
    assert!(server.windows(2).any(|args| args == ["--config", "model_reasoning_effort=\"low\""]));
    assert_eq!(server.last().unwrap(), "unix:///tmp/cx.sock");
    let own_notify = server.iter().position(|arg| arg == "notify=[\"/bin/sh\",\"/home/agent/.rudder/notify.sh\"]").unwrap();
    let earlier_notify = server.iter().position(|arg| arg.starts_with("--config=notify=")).unwrap();
    assert!(own_notify > earlier_notify, "owned report hook wins on the actual server");
    assert!(!server.iter().any(|arg| arg == "hello"), "task input belongs only to the remote frontend");
    let mcp: serde_json::Value = serde_json::from_slice(&files.iter().find(|file|file.relative_path == Path::new(".rudder/mcp.json")).unwrap().contents).unwrap();
    assert_eq!(mcp["mcpServers"]["rudder_agents"]["command"], "/opt/rudder/native");
    assert!(mcp.to_string().contains("/run/rudder/agent/identity.json"));
    assert!(!mcp.to_string().contains("/workspace/home"));

    let claude = ManagedBackendProfile::ClaudeSdk { node: "/usr/bin/node".into(), rudder_cli: "/opt/rudder/main.js".into(),
        claude: "/opt/runtime/claude".into(), arguments: vec!["--model".into(), "chosen-model".into()], initial_prompt: Some("exact prompt".into()) };
    let (terminal, server, files) = prepare_backend(&fence, &claude, "/opt/rudder/native", Path::new("/tmp/cx.sock")).unwrap();
    assert!(server.is_none());
    assert_eq!(terminal.last().unwrap(), "/home/agent/.rudder/claude-launch.json");
    let launch: serde_json::Value = serde_json::from_slice(&files.iter().find(|file|file.relative_path == Path::new(".rudder/claude-launch.json")).unwrap().contents).unwrap();
    assert_eq!(launch["attempt_id"], fence.attempt_id);
    assert_eq!(launch["socket_path"], "/tmp/cx.sock");
    assert_eq!(launch["claude_args"], serde_json::json!(["--model", "chosen-model", "--mcp-config", "/home/agent/.rudder/mcp.json", "--settings", "/home/agent/.rudder/claude-settings.json"]));
    assert_eq!(launch["initial_prompt"], "exact prompt");
    let nested = ManagedBackendProfile::CodexAppServer { program: "/opt/runtime/codex".into(), arguments: vec!["--remote=unix:///peer.sock".into()] };
    assert!(prepare_backend(&fence, &nested, "/opt/rudder/native", Path::new("/tmp/cx.sock")).is_err());
}
